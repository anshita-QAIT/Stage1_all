from utility import *
from time import time
import json
import logging

#bapan1690814+9096@gmail.com
#@bapan

User_new={
  "data": {
    "type": "user",
    "attributes": {
      "email": "ma@ba.com",
      "fields": {
        "DOJ": "mmmmmnnnn",
        "DEP": "a"
      },
      "name": "Bapanbbbb",
      "profile": "learner",
      "roles": [
        "Learner"
      ],
      "state": "ACTIVE",
      "userType": "INTERNAL",
      "userUniqueId": "MMMMMKKKKMMM"
    },
    "relationships": {
      "account": {
        "data": {
          "id": "4885",
          "type": "account"
        },
        "manager": {
          "data": {
            "id": "5628836",
            "type": "user"
          }
        }
      }
    }
  }
}

User_update={
  "data":{
      "id": "5628785",
      "type": "user",
      "attributes": {
        "email": "bapan@bapanbapan.com",
        "fields": {
          "DOJ": "23-4-12",
          "DEP": "b"
        },
        "name": "PATCHUPDATE  ME",
        "pointsEarned": 0,
        "profile": "learner",
        "roles": [
          "Learner"
        ],
        "state": "ACTIVE",
        "userType": "INTERNAL",
        "userUniqueId": "MMMMMKKKKMMM"
      },
      "relationships": {
        "account": {
          "data": {
            "id": "4885",
            "type": "account"
          }
        },
        "manager": {
          "data": {
            "id": "5628658",
            "type": "user"
          }
        }
      }
    }
}


########################################################## JSON MODIFIER #########################################################################

# *******************************************************************************#
# The json modifier functions helps you to set the values for the keys in payload#
#                                                                                #
#********************************************************************************#


#Can change the default values set in the post body using this function.

def json_modifier_prerun(manger_id,account_id,email_id,name,profile,uuid,**kwargs):
    User_new["data"]["relationships"]["account"]["data"]["id"]=str(account_id)
    User_new["data"]["relationships"]["manager"]["data"]["id"]=str(manger_id)
    User_new["data"]["attributes"]["email"]=str(email_id)
    User_new["data"]["attributes"]["name"]=str(name)
    User_new["data"]["attributes"]["profile"]=str(profile)
    User_new["data"]["attributes"]["userUniqueId"]=str(uuid)
    for key,val in kwargs:
        User_new["data"]["attributes"]["fields"][key]=val


#Can change the default values set in the patch body using this function.

def json_modifier_prerun(manger_id,account_id,email_id,name,profile,uuid,**kwargs):
    User_update["data"]["relationships"]["account"]["data"]["id"]=str(account_id)
    User_update["data"]["relationships"]["manager"]["data"]["id"]=str(manger_id)
    User_update["data"]["attributes"]["email"]=str(email_id)
    User_update["data"]["attributes"]["name"]=str(name)
    User_update["data"]["attributes"]["profile"]=str(profile)
    User_update["data"]["attributes"]["userUniqueId"]=str(uuid)
    for key,val in kwargs:
        User_update["data"]["attributes"]["fields"][key]=val



#The function sets the manager id and account id
# manager_id represents the prime id for the manager of the user
#Account id represents the id of the account of which the user is a part.

def json_modifier_manger_account_patch(manger_id,account_id):
    global User_update
    User_new["data"]["relationships"]["account"]["data"]["id"]=str(account_id)
    User_new["data"]["relationships"]["manager"]["data"]["id"]=str(manger_id)


#The function sets the manager id and account id
# manager_id represents the prime id for the manager of the user
#Account id represents the id of the account of which the user is a part.

def json_modifier_manger_account_post(manger_id,account_id):
    global User_new
    User_new["data"]["relationships"]["account"]["data"]["id"]=str(account_id)
    User_new["data"]["relationships"]["manager"]["data"]["id"]=str(manger_id)


#The function sets the user id for the user.
#This is required when you are doing user PATCH.Through this you can change the user id when required.

def json_modifier_id(userid):
    global User_update
    User_update["data"]["id"]=str(userid)


#The below json modifier cancatenate the default values in (User_new) with time  which is there in the diction
#!CAUTION   While using this function,take care that deault values are there in (User_new) dictionary
#This function concatenates default values in user_new with current time.

def json_modifier():
    global User_new
    User_new["data"]["attributes"]["email"]=User_new["data"]["attributes"]["email"].split('.')[0]+str(time())+'.'+'com'
    User_new["data"]["attributes"]["userUniqueId"]=User_new["data"]["attributes"]["userUniqueId"]+str(time())



#This function helps you to set the values for the email and uuid for POST payload.
#This will cancatenate the email id provided by you with time everytime the automation runs.

def json_modifier_post(email_id,uuid):
    global User_new
    User_new["data"]["attributes"]["email"]=str(email_id)+str(time())
    User_new["data"]["attributes"]["userUniqueId"]=str(uuid)+str(time())


#Update the email field of the user.
#This helps you to set the email id for the PATCH payload.
#This concatenates the default email id with time and update the email id for the user.

def json_modifier_user_update_email():
  global User_update
  User_update["data"]["attributes"]["email"]=User_update["data"]["attributes"]["email"]+str(time())


#Can set the custom email id using this function.
def json_modifier_user_update_email_patch(email_id):
  global User_update
  User_update["data"]["attributes"]["email"]=str(email_id)+str(time())


#Update the user name.
def json_modifier_user_update_name():
  global User_update
  User_update["data"]["attributes"]["name"]=User_update["data"]["attributes"]["name"]+str(time())


#Update the active fields of the user.
#This will only work if the active fields set in your account is same as mentioned in the User_updatebody

def json_modifier_user_update_fields(doj,value):
  global User_update
  User_update["data"]["attributes"]["fields"]["DOJ"]=str(doj)
  User_update["data"]["attributes"]["fields"]["DEP"]=str(value)


#Update the active fields of the user.
#This will only work if any no of active fields keys if you have added in your account.
#!CAUTION the number of arguments you provide should be same as the no of keys you have in your account.
#!CAUTION  the active fields should be present in your accounts

def json_modifier_user_update_fields_patch(*args):
  global User_update
  for key in User_update["data"]["attributes"]["fields"].keys():
      User_update["data"]["attributes"]["fields"][key]=args[i]
        

#Create the active fields of the user.
#This will only work if any no of active fields keys if you have added in your account.
#!CAUTION the number of arguments you provide should be same as the no of active field keys you have in your account.
#!CAUTION the active fields should be present in your account

def json_modifier_user_create_fields_post(*kwargs):
  global User_new
  for key,val in User_new["data"]["attributes"]["fields"].items():
      User_new["data"]["attributes"]["fields"][key]=val


#Update the active fields of the user.
def json_modifier_user_update_uuid(uuid):
  global User_update
  User_update["data"]["attributes"]["userUniqueId"]=str(uuid)
  


######################################################################### REQUST DECORATOR ###########################################################


#POST request function for testing basic functionality of POST method
@post_request_payload
def post_user(*args):
      return args[3]

#POST request function for getting the response body of the post method.
@post_request_payload
def post_get_user_body(*args):
      return args[2]

#GET request function to retrieve the user by id.
@get_request
def get_user_by_id(*args):
    return args[2]

@get_request
def get_userbody_by_id(*args):
    return args[1]

#PATCH request to test the basic functionality of the PATCH method.
@patch_request_payload
def patch_update_user(*args):
  return args[3]

#PATCH request function to test the PATCH api response body using GET.
@patch_request_payload
def patch_update_user_get_body(*args):
  return args[2]

@delete_request_parameter
def  delete_user_by_id(*args):
    return args[1]


###################################################################### TEST CASE(VALIDATION FUNCTIONS) ########################################################################

#Test the user creation through post method
#Testcase represents the testcase string
@Report_generate
def  test_create_user(Testcase):
     try:
         json_modifier()
         res = post_user("users", json.dumps(User_new))
         if res == 200:
             return True
         else:
             return False
     except Exception as e:
         return False

#Testcase is the testcase string
#id is the id of the user who is just created.
#Here we create the user and try to retieve the user using GET method.

@Report_generate
def  test_create_retrieve_user(Testcase):
     try:
         json_modifier()
         res = post_get_user_body("users", json.dumps(User_new))
         id = res["data"]["id"]
         str1 = "users/" + str(id)
         res = get_user_by_id(str1)
         if res == 200:
             return True
         else:
             return False
     except Exception as e:
         return False

#Testcase is the testcase string.
#id is the id of the user.
#Update the user email using patch.

@Report_generate
def  test_update_user_email(Testcase,id):
     try:
         json_modifier_id(id)
         json_modifier_user_update_email()
         str1 = "users/" + str(id)
         res = patch_update_user(str1, json.dumps(User_update))
         if res == 200:
             return True
         else:
             return False
     except Exception as e:
         return False


#Basic test patch user.
@Report_generate
def basic_test_patch_body(Testcase,id):
   try:
       json_modifier_id(id)
       str1 = "users/" + str(id)
       res = patch_update_user(str1, json.dumps(User_update))
       if res == 200:
           return True
       else:
           return False
   except Exception as e:
       return False

#Testcase is the testcase string.
#Update the user name using patch.

@Report_generate
def  test_update_user_name(Testcase,id):
     try:
         json_modifier_id(id)
         json_modifier_user_update_name()
         str1 = "users/" + str(id)
         res = patch_update_user(str1, json.dumps(User_update))
         if res == 200:
             return True
         else:
             return False
     except Exception as e:
         return False

#Testcase is the testcase string
#Update the uuid through patch.

@Report_generate
def  test_update_user_uuid(Testcase,id,uuid):
     try:
         json_modifier_id(id)
         json_modifier_user_update_uuid(uuid)
         str1 = "users/" + str(id)
         res = patch_update_user(str1, json.dumps(User_update))
         if res == 200:
             return True
         else:
             return False
     except Exception as e:
         return False


#Testcase is the testcase string.
#Update the active fields of the user.

@Report_generate
def  test_update_user_fields(Testcase,doj,field,id):
     try:
         json_modifier_id(id)
         json_modifier_user_update_fields(doj, field)
         str1 = "users/" + str(id)
         res = patch_update_user(str1, json.dumps(User_update))
         if res == 200:
             return True
         else:
             return False
     except Exception as e:
         return False


@Report_generate
def  test_update_user_fields_get_by_id(Testcase,doj,field,id):
     try:
         json_modifier_id(id)
         json_modifier_user_update_fields(doj, field)
         str1 = "users/" + str(id)
         res = patch_update_user_get_body(str1, json.dumps(User_update))
         id = res["data"]["id"]
         res = get_userbody_by_id(str1)
         if res["data"]["attributes"]["fields"]["DEP"] == str(field):
             return True
         else:
             return False
     except Exception as e:
         return False


@Report_generate
def  test_update_user_name_get_by_id(Testcase,name,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         User_update["data"]["attributes"]["name"] = name
         res = patch_update_user_get_body(str1, json.dumps(User_update))
         id = res["data"]["id"]
         res = get_userbody_by_id(str1)
         if res["data"]["attributes"]["name"] == name:
             return True
         else:
             return False
     except Exception as e:
         return False


@Report_generate
def  test_update_user_email_get_by_id(Testcase,email,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         User_update["data"]["attributes"]["email"] = email
         res = patch_update_user_get_body(str1, json.dumps(User_update))
         id = res["data"]["id"]
         res = get_userbody_by_id(str1)
         if res["data"]["attributes"]["email"] == email:
             return True
         else:
             return False
     except Exception as e:
         return False



@Report_generate
def  test_update_user_uuid_get_by_id(Testcase,uuid,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         User_update["data"]["attributes"]["userUniqueId"] = str(uuid)
         res = patch_update_user_get_body(str1, json.dumps(User_update))
         id = res["data"]["id"]
         res = get_userbody_by_id(str1)
         if res["data"]["attributes"]["userUniqueId"] == uuid:
             return True
         else:
             return False
     except Exception as e:
         return False

@Report_generate
def  test_update_user_manager_get_by_id(Testcase,mid,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         User_update["data"]["relationships"]["manager"]["data"]["id"] = str(mid)
         res = patch_update_user_get_body(str1, json.dumps(User_update))
         id = res["data"]["id"]
         res = get_userbody_by_id(str1)
         if res["data"]["relationships"]["manager"]["data"]["id"] == str(mid):
             return True
         else:
             return False
     except Exception as e:
         return False


#Testcase is the testcase string.
#id is the user id.
#Added manager role along with current role.


@Report_generate
def  test_update_user_role_upgrade_to_Instructor_get_by_id(Testcase,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         res = get_userbody_by_id(str1)
         res["data"]["attributes"]["roles"].append("Instructor")
         res = patch_update_user_get_body(str1, json.dumps(res))
         res = get_userbody_by_id(str1)
         if "Manager" in res["data"]["attributes"]["roles"]:
             return True
         else:
             return False
     except Exception as e:
         return False


#Testcase is the testcase string.
#id is the user id.
#Removed manager role along with current role.

@Report_generate
def  test_update_user_role_downgrade_from_Instructor_to_learner_get_by_id(Testcase,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         res = get_userbody_by_id(str1)
         res["data"]["attributes"]["roles"].remove("Instructor")
         res = patch_update_user_get_body(str1, json.dumps(res))
         res = get_userbody_by_id(str1)
         if "Instructor" not in res["data"]["attributes"]["roles"]:
             return True
         else:
             return False
     except Exception as e:
         return False


#Testcase is the testcase string.
#id is the user id.
#Added author role along with current role.

@Report_generate
def  test_update_user_role_upgrade_to_author_get_by_id(Testcase,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         res = get_userbody_by_id(str1)
         res["data"]["attributes"]["roles"].append("Author")
         res = patch_update_user_get_body(str1, json.dumps(res))
         res = get_userbody_by_id(str1)
         if "Author" in res["data"]["attributes"]["roles"]:
             return True
         else:
             return False
     except Exception as e:
          return False

#Testcase is the testcase string.
#id is the user id.
#Removed author role along with current role.

@Report_generate
def  test_update_user_role_downgrade_from_author_to_learner_get_by_id(Testcase,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         res = get_userbody_by_id(str1)
         res["data"]["attributes"]["roles"].remove("Author")
         res = patch_update_user_get_body(str1, json.dumps(res))
         res = get_userbody_by_id(str1)
         if "Author" not in res["data"]["attributes"]["roles"]:
             return True
         else:
             return False
     except Exception as e:
         return False

#Testcase is the testcase string.
#id is the user id.
#Added Integration Admin role along with current role.

@Report_generate
def  test_update_user_role_upgrade_to_IA_get_by_id(Testcase,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         res = get_userbody_by_id(str1)
         res["data"]["attributes"]["roles"].append("Integration Admin")
         res = patch_update_user_get_body(str1, json.dumps(res))
         res = get_userbody_by_id(str1)
         if "Integration Admin" in res["data"]["attributes"]["roles"]:
             return True
         else:
             return False
     except Exception as e:
         return False

#Testcase is the testcase string.
#id is the user id.
#Removed Integration Admin role along with current role.

@Report_generate
def  test_update_user_role_downgrade_from_IA_to_learner_get_by_id(Testcase,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         res = get_userbody_by_id(str1)
         res["data"]["attributes"]["roles"].remove("Integration Admin")
         res = patch_update_user_get_body(str1, json.dumps(res))
         res = get_userbody_by_id(str1)
         if "Integration Admin" not in res["data"]["attributes"]["roles"]:
             return True
         else:
             return False
     except Exception as e:
         return True


#Testcase is the testcase string.
#id is the user id.
#Added Admin role along with current role.

@Report_generate
def  test_update_user_role_upgrade_to_Admin_get_by_id(Testcase,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         res = get_userbody_by_id(str1)
         res["data"]["attributes"]["roles"].append("Admin")
         res = patch_update_user_get_body(str1, json.dumps(res))
         res = get_userbody_by_id(str1)
         if "Admin" in res["data"]["attributes"]["roles"]:
             return True
         else:
             return False
     except Exception as e:
         return False


#Testcase is the testcase string.
#id is the user id.
#Removed Admin role along with current role.

@Report_generate
def  test_update_user_role_downgrade_from_Admin_get_by_id(Testcase,id):
     try:
         json_modifier_id(id)
         str1 = "users/" + str(id)
         res = get_userbody_by_id(str1)
         res["data"]["attributes"]["roles"].remove("Admin")
         res = patch_update_user_get_body(str1, json.dumps(res))
         res = get_userbody_by_id(str1)
         if "Admin" not in res["data"]["attributes"]["roles"]:
             return True
         else:
             return False
     except Exception as e:
         return False


# @Report_generate
# def  test_manager_role_for_user(Testcase):
#      json_modifier()
#      res=post_get_user_body("users",json.dumps(User_new))
#      id=res["data"]["id"]
#      User_new["data"]["relationships"]["manager"]["data"]["id"]=str(id)
#      res=post_get_user_body("users",json.dumps(User_new))
#      str1="users/"+str(id)
#      res=get_userbody_by_id(str1)
#      if "Manager" in res["data"]["attributes"]["roles"]:
#          return True
#      else:
#          return False

@Report_generate
def  test_users_filter_by_mail(Testcase,email):
     try:
         str1 = "users?"
         data = get_data()
         data.clear()
         data["ids"] = "email" + "%3A" + email.split('@')[0] + "%40" + email.split('@')[1]
         print(data)
         res = get_userbody_by_id(str1)
         print(res)
         if res["data"][0]["attributes"]["email"] == email:
             return True
         else:
             return False
     except Exception as e:
         return False


@Report_generate
def  delete_users_check_status(Testcase):
     try:
         json_modifier()
         res = post_get_user_body("users", json.dumps(User_new))
         id = res["data"]["id"]
         str1 = "users/" + str(id)
         res = delete_user_by_id(str1)
         if res == 204:
             return True
         else:
             return False
     except Exception as e:
         return False


@Report_generate
def  delete_users_check_state(Testcase):
     try:
         json_modifier()
         res = post_get_user_body("users", json.dumps(User_new))
         id = res["data"]["id"]
         str1 = "users/" + str(id)
         res = delete_user_by_id(str1)
         if res == 204:
             res1 = get_userbody_by_id(str1)
             if res1["data"]["attributes"]["state"] == "DELETED":
                 return True
             else:
                 return False
         else:
             return False
     except Exception as e:
         return False




########################################################################## TEST CASE EXECUTE ################################################################


if __name__=="__main__":
   Auto_init("User1.csv")
   set_modulename(__file__)
   test_create_user("Test user creation using POST method")
   test_create_retrieve_user("Test user creation using POST and retrieve the user using GET by id")
   basic_test_patch_body("Test the basic functionality of PATCH without any field change",5628785)
   test_update_user_email("Test the user email update by PATCH",5628785)
   test_update_user_fields("Test the active fields of the user body with value a",str(time()),'a',5628785)
   test_update_user_fields("Test the active fields of the user body with value b",str(time()),'b',5628785)
   test_update_user_fields("Test the active fields of the user body with value a",str(time()),'a',5628785)
   test_update_user_fields_get_by_id("Change the active field through PATCH and verify using GET",str(time()),'b',5628785)
   test_update_user_fields("Test the active fields of the user body with value a",str(time()),'a',5628785)
   test_update_user_name("Test the user name update by patch",5628785)
   test_update_user_name_get_by_id("Change the name of the user by PATCH and verify using GET","AAAA",5628785)
   test_update_user_email_get_by_id("Change the email of the user by PATCH and verify using GET","bapan@wwf.com",5628785)
   test_update_user_email_get_by_id("Change the previous email of the user by PATCH and verify using GET","bapan2@wwf.com",5628785)
   test_update_user_uuid("Test the uuid update for the user",5628785,"K_K_K_K")
   test_update_user_uuid_get_by_id("Change the uuid using patch and verify using GET","M_M_M_M",5628785)
   test_update_user_manager_get_by_id("Update the manager id through patch and verify using GET",5628805,5628785)
   test_update_user_manager_get_by_id("Change the previous manager through PATCH and verify using GET",5628804,5628785)
   #test_update_user_role_upgrade_to_Instructor_get_by_id("Upgrade role to Instructor for a user having learner role",5628812)
   #test_update_user_role_downgrade_from_Instructor_to_learner_get_by_id("Downgrade role for a user from Instructor to learner",5628812)
   test_update_user_role_upgrade_to_author_get_by_id("Upgrade the role from learner to author",5628813)
   test_update_user_role_downgrade_from_author_to_learner_get_by_id("Downgrade the role from author to learner",5628813)
   test_update_user_role_upgrade_to_IA_get_by_id("Upgrade the role of a learner to Integration Admin",5628814)
   test_update_user_role_downgrade_from_IA_to_learner_get_by_id("Downgrade the role from Integration Admin to learner",5628814)
   test_update_user_role_upgrade_to_Admin_get_by_id("Upgrade the role of a learner to Admin",5628815)
   test_update_user_role_downgrade_from_Admin_get_by_id("Downgrade the role of a user from Admin to learner",5628815)
   #test_users_filter_by_mail("Test the user filter by email","b@gmail.com")
   delete_users_check_status("Delete user by id and check http status code")
   delete_users_check_state("Delete user by id and check state of the deleted user.")
   Auto_close()







