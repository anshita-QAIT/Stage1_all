from utility import *
import json

@get_request
def get_enrollment(*args):
    return args[1],args[2]

@post_request
def post_enrollment(*args):
    return args[2],args[3]


@post_request_payload
def postrequest(*args):
    return args[2],args[3]



def post_request_usergroup(func):
    global cred
    global l
    global data
    @wraps(func)
    def wrapper(*args):
        str1="https://captivateprimestage1.adobe.com"+"/primeapi/v2/"+str(args[0])
        Access_Token = get_New_Token("https://captivateprimestage1.adobe.com/",cred)
        hdr = {"Authorization": "oauth " + str(Access_Token["access_token"]),"Content-Type": "application/vnd.api+json","Accept": "application/vnd.api+json"}
        res = post(str1,params=data,headers=hdr,data=args[1])
        print(res)
        return func(args[0],args[1],res.status_code)
    return wrapper


@post_request_usergroup
def post_usergroup(*args):
    return args[2]


class User:
   def __init__(self):
       self.type="user"
       self.attributes={"email":"tag@tag2.com","name": "tag tag1","profile": "learner","state":"ACTIVE","userType": "INTERNAL"}
   def modify_email(self):
       email=self.attributes["email"].split('@')
       self.attributes["email"]=email[0]+str(time())+'@'+email[1]
   def get_payload(self):
       payload={"data":self.__dict__}
       return json.dumps(payload)


class User_Group:
    def __init__(self,userid):
        self.type="user"
        self.id=userid
     
    def get_payload(self):
        payload=list.append(self.__dict__)
        return json.dumps({"data":payload})
    
    


@Report_generate
def test_enrollment_source_MGR_approve(testcase,loid,loinstanceid,enrollmentsource,enrollmentstate):
    try:
       urls="enrollments"
       data=get_data()
       data.clear()
       data["loId"]=str(loid)
       data["loInstanceId"]=str(loinstanceid)
       res_post,status_post=post_enrollment(urls,data)
       if status_post!=200:
          raise Exception
    except Exception as e:
       return False
    try:
       urls="enrollments/"+res_post["data"]["id"]
       res_get,status_get=get_enrollment(urls)
       if res_get["data"]["attributes"]["enrollmentSource"]==enrollmentsource and res_get["data"]["attributes"]["state"]==enrollmentstate:
          return True
       else:
          return False
    except Exception as e:
       return False


@Report_generate
def test_enrollment_source_MGR_nomntd(testcase,enrollmentid,enrollmentsource):
    try:
      data=get_data()
      data.clear()
      urls="enrollments/"+enrollmentid
      res_get,status_get=get_enrollment(urls)
      if status_get!=200:
         raise Exception
    except Exception as e:
       return False
    try:
       if res_get["data"]["attributes"]["enrollmentSource"]==enrollmentsource:
          return True
       else:
          return False
    except Exception as e:
       return False



@Report_generate
def test_enrollment_source_Auto_enroll(testcase,enrollmentid,enrollmentsource):
    try:
      data=get_data()
      data.clear()
      urls="enrollments/"+enrollmentid
      res_get,status_get=get_enrollment(urls)
      if status_get!=200:
         raise Exception
    except Exception as e:
       return False
    try:
       if res_get["data"]["attributes"]["enrollmentSource"]==enrollmentsource:
          return True
       else:
          return False
    except Exception as e:
       return False



@Report_generate
def test_enrollment_source_Self_enroll(testcase,loid,loinstanceid,enrollmentsource,enrollmentstate):
    try:
       urls="enrollments"
       data=get_data()
       data.clear()
       data["loId"]=loid
       data["loInstanceId"]=loinstanceid
       res_post,status_post=post_enrollment(urls,data)
       if status_post!=200:
          raise Exception
    except Exception as e:
       return False
    try:
       urls="enrollments/"+res_post["data"]["id"]
       res_get,status_get=get_enrollment(urls)
       if status_get!=200:
          raise Exception
       if res_get["data"]["attributes"]["enrollmentSource"]==enrollmentsource and res_get["data"]["attributes"]["state"]==enrollmentstate:
          return True
       else:
          return False
    except Exception as e:
       return False



@Report_generate
def test_enrollment_source_Auto_enroll_admin(testcase,usergroupid,loid,loinstanceid,enrollmentsource,enrollmentstate):
    try:
       urls="users"
       data=get_data()
       data.clear()
       user=User()
       user.modify_email()
       payload=user.get_payload()
       res_post,status_post=postrequest("users",payload)
       if status_post!=200:
          raise Exception
       enrollment_id=str(loid)+'_'+str(loinstanceid).split('_')[-1]+'_'+res_post["data"]["id"]
    except Exception as e:
       return False
    try:
       urls="users/"+str(res_post["data"]["id"])+"/enrollments"
       count=20
       while count:
           count=count-1
           data=get_data()
           data.clear()
           data["filter.loTypes"]="course"
           res_get,status_get=get_enrollment(urls)
           if status_get==200:
             if res_get["data"][0]["attributes"]["enrollmentSource"]==enrollmentsource and res_get["data"][0]["attributes"]["state"]==enrollmentstate:
                     return True
           else:
             sleep(4)
       return False
    except Exception as e:
       return False




if __name__=="__main__":
   Auto_init('enrollment_source.csv')
   set_modulename(__file__)
   Env_init("f36aa10e-cd67-430a-82c2-7b2807a84742","be6af0f9-e601-47c2-84c2-85482ad18512","b9defb7fb041c1f24b133dbccef97bcf")
   test_enrollment_source_MGR_approve("Verify the enrollment source and enrollment state for manager approved course","course:3101979","course:3101979_5770615","MGR_APPROVAL","PENDING_APPROVAL")
   test_enrollment_source_MGR_nomntd("Verify that enrollment source appears as admin enroll for manager nominated course if enrolled by admin","course:3101981_5770617_9918553","ADMIN_ENROLL")
   test_enrollment_source_MGR_nomntd("Verify that enrollment source for course nominated by manager of the user","course:3101996_5770632_9918553","MGR_ENROLL")
   test_enrollment_source_Self_enroll("Verify the enrollment source for courses self enrolled by learner","course:3101997","course:3101997_5770633","SELF_ENROLL","ENROLLED")
   test_enrollment_source_Auto_enroll("Verify the enrollment source for coures auto enrolled by learner","course:3101999_5770635_9918553","AUTO_ENROLL")
   Env_init("ec8ce744-2afb-40cc-b5e9-c7bcef5d6402","8a31fd12-32e5-46b9-baae-2006ba7d4093","f634b5d3c785a9bf1dd0c8584be01161")
   test_enrollment_source_Auto_enroll_admin("Verify that the learner is auto enrolled to a learning plan","1397692","course:3101999","course:3101999_5770635","AUTO_ENROLL","ENROLLED")
   Auto_close()