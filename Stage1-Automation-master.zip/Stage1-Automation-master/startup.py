import sys


def create_test(argument):
    try:
       startcode=None
       with open("startup.txt",'r') as file:
         startcode=file.read()
       with open(argument,'w') as file:
         file.write(startcode)
    except Exception as e:
       print("Config Error")



if __name__=="__main__":
   if sys.argv[1]=="createtest":
      try:
         create_test(sys.argv[2]+".py")
      except Exception as e:
         print("Invalid command")

   
