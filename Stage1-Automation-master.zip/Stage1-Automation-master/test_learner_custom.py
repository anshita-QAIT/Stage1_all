from utility import *
import json
#@author 'Bapan Biswas'

class User:
    def __init__(self,id):
        self.id=id
        self.type="user"
        self.attributes={"bio":'',"contentLocale":'',"timeZoneCode":'',"uiLocale":'',}
        self.relationships={"account":{"data":{"id":"","type":"account"}},"manager":{"data":{"id":"","type":"user"}}}

    @property
    def set_attributes(self):
        return self.attributes

    @set_attributes.setter
    def set_attributes(self,**kwargs):
        self.attributes.clear()
        for key,value in kwargs:
            self.attributes[key]=value
    @property
    def set_relationship(self):
        return self.relationship

    @set_relationship.setter
    def set_relationship(self,**kwargs):
        self.relationships.clear()
        for key,value in kwargs:
            self.relationships[key]=value

    def create_payload(self):
        body={"data":self.__dict__}
        return json.dumps(body)

    def add_roles(self,role):
        if "roles" in self.attributes:
            if role not in self.attributes["roles"]:
                self.attributes["roles"].append(role)

    def add_multiple_roles(self,*args):
        if "roles" in self.attributes:
            for role in args:
                if role not in self.attributes["roles"]:
                    self.attributes["roles"].append(role)

    def clear_roles(self,*args):
        if "roles" in self.attributes:
            self.attributes["roles"].clear()


    def modify_bio(self,bio):
        if "bio" in self.attributes:
            self.attributes["bio"]=bio

    def modify_contentlocale(self,contentlocale):
        if "contentLocale" in self.attributes:
            self.attributes["contentLocale"]=contentlocale

    def modify_timezone(self,timezone):
        if "timeZoneCode" in self.attributes:
            self.attributes["timeZoneCode"]=timezone

    def modify_uilocale(self,uilocale):
        if "uiLocale" in self.attributes:
            self.attributes["uiLocale"]=uilocale

    def modify_manager(self,managerid):
        if "manager" in self.relationships:
            self.relationships["manager"]["data"]["id"]=str(managerid)

    def modify_account(self,accountid):
        if "account" in self.relationships:
            self.relationships["account"]["data"]["id"] = str(accountid)


@get_request
def get_request(*args):
    return args[1],args[2]

@patch_request_payload
def patch_request(*args):
    return args[2],args[3]


@Report_generate
def test_patch_user_basic(testcase,obj,*args):
    data = get_data()
    data.clear()
    try:
        str1="users/"+obj.id
        payload=obj.create_payload()
        res,status=patch_request(str1,payload)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res["data"]["attributes"]["uiLocale"]==args[0] and res["data"]["attributes"]["contentLocale"]==args[1] and res["data"]["attributes"]["bio"]==args[2]:
            return True
        return False
    except Exception as e:
        return False


@Report_generate
def test_patch_user_uilocale_update(testcase,obj,uilocale):
    data = get_data()
    data.clear()
    try:
        obj.modify_uilocale(uilocale)
        str1 = "users/" + obj.id
        payload = obj.create_payload()
        res, status = patch_request(str1, payload)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res["data"]["attributes"]["uiLocale"]==uilocale:
            return True
        return False
    except Exception as e:
        return False

@Report_generate
def test_patch_user_contentlocale_update(testcase,obj,contentlocale):
    data = get_data()
    data.clear()
    try:
        obj.modify_contentlocale(contentlocale)
        str1 = "users/" + obj.id
        payload = obj.create_payload()
        res, status = patch_request(str1, payload)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
       if res["data"]["attributes"]["contentLocale"]==contentlocale:
          return True
       return False
    except Exception as e:
        return False


@Report_generate
def test_patch_user_timezone_update(testcase,obj,timezone):
    data = get_data()
    data.clear()
    try:
        obj.modify_timezone(timezone)
        str1 = "users/" + obj.id
        payload = obj.create_payload()
        res, status = patch_request(str1, payload)
        if status!=200:
            return Exception
    except Exception as e:
        return False
    try:
        if res["data"]["attributes"]["timeZoneCode"]==timezone:
            return True
        return False
    except Exception as e:
        return False

@Report_generate
def test_patch_user_bio_update(testcase,obj,bio):
    data = get_data()
    data.clear()
    try:
        obj.modify_bio(bio)
        str1 = "users/" + obj.id
        payload = obj.create_payload()
        res, status = patch_request(str1, payload)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res["data"]["attributes"]["bio"]==bio:
            return True
        return False
    except Exception as e:
        return False


@Report_generate
def test_patch_user_verify_GET(testcase,obj,*args):
    data = get_data()
    data.clear()
    try:
        str1="users/"+obj.id
        obj.modify_bio(args[0])
        obj.modify_contentlocale(args[1])
        obj.modify_timezone(args[2])
        payload=obj.create_payload()
        res,status=patch_request(str1,payload)
        if status!=200:
            raise Exception
        res1,status=get_request(str1)
        if status!=200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res["data"]["attributes"]["bio"]==res1["data"]["attributes"]["bio"] and res["data"]["attributes"]["contentLocale"]==res1["data"]["attributes"]["contentLocale"] and res["data"]["attributes"]["timeZoneCode"]==res1["data"]["attributes"]["timeZoneCode"]:
            return True
        return False
    except Exception as e:
        return False


if __name__=="__main__":
   Auto_init("learner_custom_role.csv")
   set_modulename(__file__)
   Env_init("a897a734-7c8a-4969-a5c9-36672be74003","d7b202e6-edbb-4b13-b120-795ef693c55b","1f554db979dfec2e4b54e37b8d121aeb")
   user=User("7475530")
   user.modify_bio("Hello")
   user.modify_contentlocale("en-US")
   user.modify_timezone("IST")
   user.modify_manager("7475525")
   user.modify_uilocale("en-US")
   user.modify_account("6086")
   test_patch_user_basic("Verify the basic functionality of patch user having custom role",user,"en-US","en-US","Hello")
   test_patch_user_uilocale_update("Verify the uilocale french set by the learner",user,"fr-FR")
   test_patch_user_uilocale_update("Verify the uilocale english set by the learner", user, "en-US")
   test_patch_user_contentlocale_update("Verify the content locale english set by the learner",user,"en-US")
   test_patch_user_contentlocale_update("Verify the content locale english set by the learner", user,"fr-FR")
   test_patch_user_contentlocale_update("Verify the content locale english set by the learner", user, "en-US")
   test_patch_user_bio_update("Verify the bio update for the user having custom role",user,"Hello Hello Hello")
   test_patch_user_timezone_update("Verify the timezone update for the learner with custom role",user,"356")
   test_patch_user_timezone_update("Verify the timezone update for the learner with custom role", user,"IST")
   test_patch_user_verify_GET("Verify the patch update bio contentlocale timezone for the learner",user,"Bello Bello","fr-FR","IST")
   user = User("7475530")
   user.modify_bio("Hello")
   user.modify_contentlocale("en-US")
   user.modify_contentlocale("en-US")
   user.modify_timezone("IST")
   user.modify_manager("7475525")
   user.modify_uilocale("en-US")
   user.modify_account("6086")
   test_patch_user_basic("Verify the basic functionality of patch user having custom role",user,"en-US","en-US","Hello")
   Auto_close()