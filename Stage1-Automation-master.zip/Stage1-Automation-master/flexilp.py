from utility import *
import json

@patch_request_payload
def patch_request(*args):
    return args[2],args[3]

@post_request_payload
def postrequest(*args):
    return args[2],args[3]

@get_request
def get_request(*args):
    return args[1],args[2]

@delete_request_parameter
def delete_request(*args):
    return args[1]

@post_request
def post_request_param(*args):
    return args[2],args[3]



class Enrollment:
   def __init__(self):
      self.enroll={}

   def update_enroll(self,courseinstanceid):
          self.enroll.clear()
          d={courseinstanceid.split('_')[0]:courseinstanceid}
          self.enroll.update(d)

   def remove_enroll(self,courseid):
       if courseid in self.enroll:
          del self.enroll[courseid]

   def get_payload(self):
       return json.dumps(self.__dict__)

   def update_enroll_many(self,*courseinstanceid):
          self.enroll.clear()
          d=dict()
          for instance in courseinstanceid:
              d[instance.split('_')[0]]=instance
          self.enroll.update(d)

def get_enrollment_payload(courseinstanceid):
    enroll=Enrollment()
    enroll.update_enroll(courseinstanceid)
    return enroll.get_payload()

@Report_generate
def test_enroll_flexilp(testcase,lpid,lpinstanceid,courseinstanceid):
    test=False
    enroll_id=''
    data=get_data()
    data.clear()
    data["loId"]=lpid
    data["loInstanceId"]=lpinstanceid
    try:
       payload=get_enrollment_payload(courseinstanceid)
       url1="enrollments"
       res,statuscode=postrequest(url1,payload)
       if statuscode!=200:
          raise Exception
       enroll_id=res["data"]["id"]
       url2="enrollments/"+enroll_id
       res_get,status=get_request(url2)
       if status!=200:
          raise Exception
    except Exception as e:
       if statuscode==200:
          delete_request("enrollments/"+enroll_id)
       return False
    try:
       if res_get["data"]["id"]==enroll_id:
          res_g,status_g=get_request("learningObjects/"+courseinstanceid.split('_')[0])
          if status_g!=200:
             raise Exception
          str1=courseinstanceid.split('_')[0]+'_'+res_g["data"]["relationships"]["enrollment"]["data"]["id"].split('_')[1]
          if str1==courseinstanceid:
              test=True
          else:
              test=False
    except Exception as e:
      test=False
    finally:
       delete_request("enrollments/"+enroll_id)
       return test


@Report_generate
def patch_enroll_flexilp(testcase,enrollmentid,courseinstanceid):
    try:
        url="enrollments"
        data=get_data()
        data.clear()
        data["enrollmentId"]=enrollmentid
        payload=get_enrollment_payload(courseinstanceid)
        res,statuscode=patch_request(url,payload)
        if statuscode!=200:
           raise Exception
        res_get,status=get_request("learningObjects")
        if status!=200:
           raise Exception
    except Exception as e:
       return False
    try:
        data.clear()
        res_g,status_g=get_request("learningObjects/"+courseinstanceid.split('_')[0])
        if status_g!=200:
           raise Exception
        if res_g["data"]["relationships"]["enrollment"]["data"]["id"].split('_')[0]!=courseinstanceid.split('_')[0]:
           return False
        return True
    except Exception as e:
       return False


@Report_generate
def test_enroll_lo(testcase,loid,loinstanceid):
    test=False
    enroll_id='XX'
    try:
        url="enrollments/"
        data=get_data()
        data.clear()
        data["loId"]=loid
        data["loInstanceId"]=loinstanceid
        res,statuscode=post_request_param(url,data)
        if statuscode!=200:
           raise Exception
    except Exception as e:
       test=False
       return test
    try:
        data.clear()
        res_g,status_g=get_request("learningObjects/"+loid)
        if status_g!=200:
           raise Exception
        enroll_id=res_g["data"]["relationships"]["enrollment"]["data"]["id"]
        if enroll_id.split('_')[1]==loinstanceid.split('_')[1]:
           test=True
        else:
           test=False
    except Exception as e:
        test=False
    finally:
       delete_request("enrollments/"+enroll_id)
       return test


@Report_generate
def test_enroll_unenroll_lo(testcase,loid,loinstanceid):
    test=False
    enroll_id='XX'
    try:
        url="enrollments/"
        data=get_data()
        data.clear()
        data["loId"]=loid
        data["loInstanceId"]=loinstanceid
        res,statuscode=post_request_param(url,data)
        if statuscode!=200:
           raise Exception
    except Exception as e:
       test=False
       return test
    try:
        data.clear()
        res_g,status_g=get_request("learningObjects/"+loid)
        if status_g!=200:
           raise Exception
        enroll_id=res_g["data"]["relationships"]["enrollment"]["data"]["id"]
        if enroll_id.split('_')[1]==loinstanceid.split('_')[1]:
            status_del=delete_request("enrollments/"+enroll_id)
            if status_del==200:
               test=True
            else:
               test=False
        else:
           test=False
    except Exception as e:
        test=False
    finally:
       return test


if __name__=="__main__":
   Auto_init("Flexi_LP.csv")
   set_modulename(__file__)
   Env_init("4fa17b30-60b8-4b5c-b701-81bd3a68a9d5","c3b7d7e0-d164-488a-9ebe-b525d86eed2c","fb3ca809bfd7f25f784f13976e02e0fc")
   patch_enroll_flexilp("Verify the patch enrollment for course instance","learningProgram:47603_55584_8961315","course:3088774_5756471")
   patch_enroll_flexilp("Reset the enrollment for the course instance","learningProgram:47603_55584_8961315","course:3088774_5756470")
   test_enroll_lo("Verify self enrollment into the course loinstance","course:3088775","course:3088775_5756472")
   test_enroll_lo("Reset the enrollment into the course instance","course:3088775","course:3088775_5756473")
   test_enroll_lo("Verify the self enrollment into the LP instance", "learningProgram:47750", "learningProgram:47750_55738")
   test_enroll_lo("Reset the self enrollment into the LP instance", "learningProgram:47750","learningProgram:47750_55739")
   test_enroll_lo("Verify the enrollment into the Certificate instance","certification:76760","certification:76760_109865")
   test_enroll_unenroll_lo("Self enroll into a course and unenroll from the course","course:3089841","course:3089841_5757637")
   test_enroll_unenroll_lo("Self enroll into an LP and unenroll from the LP","learningProgram:47823","learningProgram:47823_55821")
   test_enroll_unenroll_lo("Self enroll into certificate and unenroll from certificate","certification:76823","certification:76823_109928")
   test_enroll_flexilp("Verify that learner can enroll into flexi LP and enroll into selected Course","learningProgram:47891","learningProgram:47891_55899","course:3090132_5757952")
   test_enroll_flexilp("Verify that learner can enroll into flexi LP and enroll into selected Course","learningProgram:47891","learningProgram:47891_55899","course:3090132_5757953")
   Auto_close()
    







       