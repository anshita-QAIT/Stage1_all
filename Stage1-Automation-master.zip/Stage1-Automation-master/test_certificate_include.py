from utility import *


@get_request
def get_lo(*args):
    return args[1]

@Report_generate
def test_certificate_include_instancebadge(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.badge"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_include_subloskillskilllevelbadge(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.skills.skillLevel.badge"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_include_certificatesublo(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.skills.skillLevel.badge"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    sublo_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObject" and obj["id"].split(':')[0]=="course":
                sublo_id.append(obj["id"])
        for obj in args:
            if obj not in sublo_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_include_certificatecourseskill(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.skills.skillLevel.badge"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    courseskill_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectSkill" and obj["id"].split(':')[0]=="course":
                courseskill_id.append(obj["id"])
        for obj in args:
            if obj not in courseskill_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_include_certificateskilllevel(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.skills.skillLevel.badge"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    skill_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="skillLevel":
                skill_id.append(obj["id"])
        for obj in args:
            if obj not in skill_id:
                return False
        return True
    except Exception as e:
        return False



@Report_generate
def test_certificate_include_certificatebadge(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.skills.skillLevel.badge"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    badge_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="badge":
                badge_id.append(obj["id"])
        for obj in args:
            if obj not in badge_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_include_skillskilllevelskilllevel(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.skills.skillLevel.skill.levels"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_include_certificateloskill(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.skills.skillLevel.skill.levels"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loskill_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectSkill" and obj["id"].split(':')[0]=="course":
                loskill_id.append(obj["id"])
        for obj in args:
            if obj not in loskill_id:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_certificate_include_skill(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.skills.skillLevel.skill.levels"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    skill_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="skill":
                skill_id.append(obj["id"])
        for obj in args:
            if obj not in skill_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_include_skilllevel(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.skills.skillLevel.skill.levels"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    skilllevel_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="skillLevel":
                skilllevel_id.append(obj["id"])
        for obj in args:
            if obj not in skilllevel_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_include_sublo(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.skills.skillLevel.skill.levels"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    sublo_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObject" and obj["id"].split(':')[0]=="course":
                sublo_id.append(obj["id"])
        for obj in args:
            if obj not in sublo_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_include_sublosinstancesloresourceresource(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.instances.loResources.resources"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_include_subloinstancesofsublos(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.instances.loResources.resources"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loinstance_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance" and obj["id"].split(':')[0]=="course":
                loinstance_id.append(obj["id"])
        for obj in args:
            if obj not in loinstance_id:
                return False
        return True
    except Exception as e:
        return False



@Report_generate
def test_certificate_include_resourceobjects(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.instances.loResources.resources"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    resource_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="resource":
                resource_id.append(obj["id"])
        for obj in args:
            if obj not in resource_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_certificate_include_loresourceobjects(Testcase,cert_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.instances.loResources.resources"
    data["ids"] = str(cert_id)
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    loresource_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectResource" and obj["id"].split(':')[0]:
                loresource_id.append(obj["id"])
        for obj in args:
            if obj not in loresource_id:
                return False
        return True
    except Exception as e:
        return False

if __name__=="__main__":
    Auto_init("Certificate_include.csv")
    set_modulename(__file__)
    Env_init("e683c33a-dc19-4657-83c1-80c063e7f852", "c66574a7-bdae-4301-9fd8-f6b53ab7c71f","427a14964641d857c974fddfcc83e8b5")
    ########################  include=instance.badge ############################################
    test_certificate_include_instancebadge("Test the include array objects related to include=instances.badge","certification:66052","certification:66052_99613","7134")
    ########################  include=subLOs.skills.skillLevel.badge #########################################
    test_certificate_include_subloskillskilllevelbadge("Test the include array objects for include=subLOs.skills.skillLevel.badge","certification:66052","7133","course:2021914_42401","course:2021915_42401","course:2021915_42400","course:2021914_42400","42400_1","42401_2","course:2021914","course:2021915")
    test_certificate_include_certificatesublo("Test the sublo objects associated with certificate in include array","certification:66052","course:2021915","course:2021914")
    test_certificate_include_certificatecourseskill("Test the course skill object associated with sublo in include array","certification:66052","course:2021914_42401","course:2021915_42401","course:2021915_42400","course:2021914_42400")
    test_certificate_include_certificateskilllevel("Test the course skill level objects in the include array","certification:66052","42400_1","42401_2")
    test_certificate_include_certificatebadge("Test the certificate badge objects in the include array","certification:66052","7133")
    ######################### include=subLOs.skills.skillLevel.skill.levels ############################################################################
    test_certificate_include_skillskilllevelskilllevel("Test the include array objects with include=subLOs.skills.skillLevel.skill.levels","certification:66052","course:2021915","course:2021914","42401_2","42400_1","42401_1","42401","42400","course:2021914_42400","course:2021915_42400","course:2021915_42401","course:2021914_42401")
    test_certificate_include_certificateloskill("Test the loskill objects related to course in include array","certification:66052","course:2021914_42401","course:2021915_42401","course:2021915_42400","course:2021914_42400")
    test_certificate_include_skill("Test the skill objects in the include array","certification:66052","42400","42401")
    test_certificate_include_skilllevel("Test the skill level objects in the include array","certification:66052","42401_1","42400_1","42401_2")
    test_certificate_include_sublo("Test the sublo objects in the include array","certification:66052","course:2021915","course:2021914")
    ########################## include=subLOs.instances.loResources.resources ###################################
    test_certificate_include_sublosinstancesloresourceresource("Test the include array objects for the include=subLOs.instances.loResources.resources","certification:66052","course:2021914_3701014","course:2021915_3701015","580668_2_en-US","580667_1_en-US","course:2021914_3701014_2659164_0","course:2021914_3701014_2659165_0","course:2021915_3701015_2659166_0","course:2021915_3701015_2659167_0","course:2021914","course:2021915")
    test_certificate_include_subloinstancesofsublos("Test the sublo instance objects in include array","certification:66052","course:2021914_3701014","course:2021915_3701015")
    test_certificate_include_resourceobjects("Test the resource object present in the include array","certification:66052","580667_1_en-US","580668_2_en-US")
    test_certificate_include_loresourceobjects("Test the loresource object in the include array","certification:66052","course:2021914_3701014_2659164_0","course:2021914_3701014_2659165_0","course:2021915_3701015_2659166_0","course:2021915_3701015_2659167_0")
    Auto_close()