from utility import *
from time import time
import json

#a@a1.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test_enrollment_completion_lo(testcase,courseid,instanceid,*args):
    data = get_data()
    data.clear()
    try:
      url="learningObjects/course%3A"+courseid.split(':')[1]+"/instances/course%3A"+instanceid.split(':')[1]+"/summary"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       if res["data"]["attributes"]["completionCount"]==args[0] and res["data"]["attributes"]["enrollmentCount"]==args[1]:
              return True
       else:
              return False
    except Exception as e:
        return False

@Report_generate
def test_seatlimit_waitlist_lo(testcase,courseid,instanceid,*args):
    data = get_data()
    data.clear()
    try:
      url="learningObjects/course%3A"+courseid.split(':')[1]+"/instances/course%3A"+instanceid.split(':')[1]+"/summary"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       if res["data"]["attributes"]["seatLimit"]==args[0] and res["data"]["attributes"]["waitlistCount"]==args[1]:
              return True
       else:
              return False
    except Exception as e:
        return False


if __name__=="__main__":
   Auto_init("course_summary.csv")
   set_modulename(__file__)
   Env_init("0c815a26-a327-4c7b-b500-d469d87ed3b6","fea7c630-83c5-4849-8558-a2713ca8d739","0b52111373144a3901875b540f6a9671")
   test_enrollment_completion_lo("Test the enrollment and completion count for the given course without seat limit","course:2037201","course:2037201_3717135",3,11)
   test_enrollment_completion_lo("Test the enrollment and completioncount for the course with seat limit","course:2037203","course:2037203_3717137",4,4)
   test_seatlimit_waitlist_lo("Test the seatlimit and waitlist status for the VC course","course:2037203","course:2037203_3717137",4,2)
   test_enrollment_completion_lo("Test the enrollment and completion count for learner for the given course","course:2037264","course:2037264_3717215",4,4)
   test_seatlimit_waitlist_lo("Test the waitlist and seat limit after the learners enrolled,unenroll themselves","course:2037264","course:2037264_3717215",4,3)
   Auto_close()
