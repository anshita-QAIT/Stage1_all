from utility import *
from time import time
import json

@get_request
def get_request(*args):
    return args[1],args[2]


def pagination(total_data,page_limit,endpoint,sortparam):
    obtained_data=0
    userdata=0
    data=get_data()
    data.clear()
    data["page[limit]"]=page_limit
    data["page[offset]"]=0
    data["sort"]=sortparam
    has_next=True
    while has_next:
       res,status=get_request(endpoint)
       if status!=200:
           return False
       print(res)
       userdata=len(res["data"])
       obtained_data=obtained_data+userdata
       if "next" in res["links"]:
           data["page[offset]"]=res["links"]["next"].split('?')[1].split('&')[0].split('=')[1]
           if userdata!=page_limit:
              return False
           elif userdata==page_limit and obtained_data==total_data:
              return False
           elif userdata==0:
              return False
           elif obtained_data>total_data:
              return False 
                       
       else:
           if obtained_data==total_data:
              has_next=False
              break
           elif obtained_data!=total_data:
              return False
           elif userdata==0 and obtained_data!=total_data:
              return False
    return True

@Report_generate
def test_pagination(testcase,total_data,page_limit,endpoint,sortparam):
    try:
       result=pagination(total_data,page_limit,endpoint,sortparam)
       return result
    except Exception as e:
        return False


def pagination_cursor(total_data,page_limit,endpoint,sortingparam):
    obtained_data=0
    userdata=0
    data=get_data()
    data.clear()
    data["page[limit]"]=page_limit
    data["sort"]=sortingparam
    has_next=True
    while has_next:
       res,status=get_request(endpoint)
       if status!=200:
           return False
       userdata=len(res["data"])
       obtained_data=obtained_data+userdata
       if "next" in res["links"]:
           data["page[cursor]"]=res["links"]["next"].split('?')[1].split('&')[-1].split('=')[1]
           if userdata!=page_limit:
              return False
           elif userdata==page_limit and obtained_data==total_data:
              return False
           elif userdata==0:
              return False
           elif obtained_data>total_data:
              return False
       else:
           if obtained_data==total_data:
              has_next=False
              break
           elif obtained_data!=total_data:
              return False
           elif userdata==0 and obtained_data!=total_data:
              return False
    return True


@Report_generate
def test_pagination_cursor(testcase,total_data,page_limit,endpoint,sortingparam):
    try:
       result=pagination_cursor(total_data,page_limit,endpoint,sortingparam)
       return result
    except Exception as e:
        return False

          
if __name__=="__main__":
   Auto_init("Userid_cursur_pagination.csv")
   set_modulename(__file__)
   Env_init("6e2ecee3-301c-4257-914c-2601ab508e06","673815e3-0753-4aad-992f-3c68d159c59a","16ea3d944c0c8a290d4cdf774880d59a")
   test_pagination_cursor("Verify the pagination of the GET user sorted by id with limit=10",57,10,"users","id")
   test_pagination_cursor("Verify the pagination of the GET user sorted by id with limit=19",57,19,"users","id")
   test_pagination_cursor("Verify the pagination of the GET user sorted by id with limit=5",57,5,"users","id")
   test_pagination_cursor("Verify the pagination of the GET user sorted by id with limit=4",57,4,"users","id")
   test_pagination_cursor("Verify the pagination of the GET user sorted by id with limit=7",57,7,"users","id")
   test_pagination_cursor("Verify the pagination of the GET user sorted by -id with limit=10", 57, 10, "users", "-id")
   test_pagination_cursor("Verify the pagination of the GET user sorted by -id with limit=5", 57, 5, "users", "-id")
   test_pagination_cursor("Verify the pagination of the GET user sorted by id with limit=19",57,19,"users","-id")
   test_pagination_cursor("Verify the pagination of the GET user sorted by -id with limit=4", 57, 4, "users", "-id")
   test_pagination_cursor("Verify the pagination of the GET user sorted by -id with limit=7", 57, 7, "users", "-id")
   test_pagination("Verify the pagination of the GET user sorted by name with limit=10",57,10,"users","name")
   test_pagination("Verify the pagination of the GET user sorted by name with limit=5", 57, 5, "users", "name")
   test_pagination("Verify the pagination of the GET user sorted by name with limit=19", 57, 19, "users", "name")
   test_pagination("Verify the pagination of the GET user sorted by name with limit=4", 57, 4, "users", "name")
   test_pagination("Verify the pagination of the GET user sorted by name with limit=7", 57,7, "users", "name")
   test_pagination("Verify the pagination of the GET user sorted by name with limit=10", 57, 10, "users","-name")
   test_pagination("Verify the pagination of the GET user sorted by name with limit=5", 57,5,"users","-name")
   test_pagination("Verify the pagination of the GET user sorted by name with limit=7", 57,7,"users","-name")
   test_pagination("Verify the pagination of the GET user sorted by name with limit=4", 57,4,"users","-name")
   test_pagination("Verify the pagination of the GET user sorted by name with limit=19", 57, 19, "users", "-name")
   Auto_close()
