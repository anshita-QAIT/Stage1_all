from utility import *
from time import time
import json

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test_catalog_levels(testcase,loid,*args):
    data = get_data()
    data.clear()
    data["ids"] =loid
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       cat_label_name=[]
       if "catalogLabels" in res["data"][0]["attributes"]:
          for obj in res["data"][0]["attributes"]["catalogLabels"]:
               cat_label_name.append(obj["name"])
       else:
           return False
       for i in args:
          if i not in cat_label_name:
             return False
       return True      
    except Exception as e:
        return False


@Report_generate
def test_tags(testcase,loid,*args):
    data = get_data()
    data.clear()
    data["filter.loTypes"]="course"
    data["ids"] =loid
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       tags=[]
       if "tags" in res["data"][0]["attributes"]:
          for obj in res["data"][0]["attributes"]["tags"]:
               tags.append(obj)
       else:
           return False
       for i in args:
          if i not in tags:
             return False
       return True      
    except Exception as e:
        return False


@Report_generate
def test_uniqueid(testcase,loid,*args):
    data = get_data()
    data.clear()
    data["filter.loTypes"]="course"
    data["ids"] =loid
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       if "uniqueId" in res["data"][0]["attributes"]:
          if res["data"][0]["attributes"]["uniqueId"]==args[0]:
             return True
       else:
          return False
    except Exception as e:
        return False


@Report_generate
def test_lo_id(testcase,loid,*args):
    data = get_data()
    data.clear()
    try:
      url="learningObjects/"+loid
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
          if res["data"]["id"]==loid:
             return True
          return False
    except Exception as e:
        return False


@Report_generate
def test_lo_filter_uuid(testcase,uuid1,uuid2,uuid3,*args):
    data = get_data()
    data.clear()
    data["ids"]="uuid:"+uuid1+",uuid:"+uuid2+",uuid:"+uuid3
    try:
      url="learningObjects/"
      res,status=get_request(url)
      print(res)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
        course=[]
        for obj in res["data"]:
          course.append(obj["id"])
        for i in args:
           if i not in course:
               return False
        return True
    except Exception as e:
        return False

    

if __name__=="__main__":
   Auto_init("Lo_Attributes.csv")
   set_modulename(__file__)
   Env_init("6e2ecee3-301c-4257-914c-2601ab508e06","673815e3-0753-4aad-992f-3c68d159c59a","16ea3d944c0c8a290d4cdf774880d59a")
   test_catalog_levels("Test the catalog labels associated with course","course:1884356","CAT 1", "CAT2")
   test_catalog_levels("Test the catalog labels associated with LP","learningProgram:26755","CAT 1","CAT2")
   test_catalog_levels("Test the catalog labels associated with Certificate","certification:45186","CAT 1")
   test_uniqueid("Test the uuid associated with course","course:1884356","A1")
   test_uniqueid("Test the uuid associated with LP","learningProgram:26755","A00000000")
   test_uniqueid("Test the uuid associated with Certificate","certification:45186","AB11")
   test_tags("Test the tags associated with course","course:1884356","tag2","tag1","tag4","tag5","tag6","tag7","tag8")
   test_tags("Test the tags associated with LP","learningProgram:26755","tag2","tag1","tag4","tag3")
   test_tags("Test the tags associated with certificate","certification:45186","tag23")
   test_lo_id("Verify the request course object by id","course:1884356")
   test_lo_id("Verify the request LP object by id","learningProgram:26755")
   test_lo_id("Verify the request Certificate object by id","certification:45186")
   test_lo_filter_uuid("Test the course object filter by ids=uuid","A1","A2","A3","course:1884356","course:1884357","course:1884358")
   test_lo_filter_uuid("Test the LP object filter by ids=uuid","A00000000","A6666666666666","A78888","learningProgram:26755","learningProgram:26756","learningProgram:26757")
   test_lo_filter_uuid("Test the Certificate object filter by ids=uuid","AB11","AB12","AB13","certification:45186","certification:45187","certification:45188")
   Auto_close()
