from utility import *
import json
from datetime import datetime
from time import sleep


class User:
   def __init__(self):
       self.type="user"
       self.attributes={"email":"tag@tag2.com","name": "tag tag1","profile": "learner","state":"ACTIVE","userType": "INTERNAL"}
   def modify_email(self):
       email=self.attributes["email"].split('@')
       self.attributes["email"]=email[0]+str(time())+'@'+email[1]
   def get_payload(self):
       payload={"data":self.__dict__}
       return json.dumps(payload)


@post_request_payload
def postrequest(*args):
    return args[2],args[3]


@post_request
def post_request_param(*args):
    return args[2],args[3]


@get_request
def get_request(*args):
    return args[1],args[2]


class Course:
   def __init__(self,courseid):
       self.id=courseid
       self.type="course"
   def get_payload(self):
       return self.__dict__


class Learner:
    def __init__(self,learnerid):
        self.id=learnerid
        self.type="user"

    def get_payload(self):
        return self.__dict__


class Module:
    def __init__(self,courseid,moduleid):
        self.id=courseid+"_"+moduleid
        self.type="courseModule"

    def get_payload(self):
        return self.__dict__

class ModuleGrade:
   def __init__(self):
      self.type="userModuleGrade"
      self.attributes={}
      self.relationships={"learner":{"data":[]},"module":{"data":[]},"course":{"data":[]}}

   def get_payload(self):
       payload={"data":self.__dict__}
       return json.dumps(payload)

   def populate_items(self,learnerid,courseid,moduleid):
       self.populate_learner(learnerid)
       self.populate_module(courseid,moduleid)
       self.populate_course(courseid)

   def populate_learner(self,learnerid):
       learner=Learner(learnerid)
       payload=learner.get_payload()
       self.relationships["learner"]["data"].append(payload)

   def populate_module(self,courseid,moduleid):
       module=Module(courseid,moduleid)
       payload=module.get_payload()
       self.relationships["module"]["data"].append(payload)

   def populate_course(self,courseid):
       course=Course(courseid)
       payload=course.get_payload()
       self.relationships["course"]["data"].append(payload)

   def populate_attributes_duration(self,duration):
       self.attributes["duration"]=duration

   def populate_attributes_score(self,score1,score2,score3):
       self.attributes["score"]=score1
       self.attributes["minScore"]=score2
       self.attributes["maxScore"]=score3

   def populate_attributes_date(self,datecompleted,datesuccess,datestarted):
       self.attributes["dateCompleted"]=datecompleted
       self.attributes["dateSuccess"]=datesuccess
       self.attributes["dateStarted"]=datestarted

   def state_of_completion(self,started,completed,success):
       self.attributes["started"]=started
       self.attributes["completed"]=completed
       self.attributes["success"]=success



def create_modulegrade_payload(learnerid,courseid,moduleid,datecompleted,datesuccess,datestarted):
       modulegrade=ModuleGrade()
       modulegrade.populate_items(learnerid,courseid,moduleid)
       modulegrade.populate_attributes_score(20,10,20)
       modulegrade.state_of_completion(True,True,True)
       modulegrade.populate_attributes_duration(1)
       modulegrade.populate_attributes_date(datecompleted,datesuccess,datestarted)
       payload=modulegrade.get_payload()
       return payload
    
    

@Report_generate
def test_createuser_enroll_complete_certificate(testcase,instanceid,courseid,certinstance,moduleid):
    try:
       user=User()
       user.modify_email()
       user_payload=user.get_payload()
       user_create,status_user=postrequest("users/",user_payload)
       if status_user!=200:
          raise Exception
       data=get_data()
       data.clear()
       data["loId"]=certinstance.split('_')[0]
       data["loInstanceId"]=certinstance
       res_enrollment,status_enrollment=post_request_param("users/"+user_create["data"]["id"]+"/enrollments",data)
       if status_enrollment!=200:
          raise Exception
       datestarted=datetime.now().isoformat().split('.')[0]+'.000Z'
       datesuccess=datetime.now().isoformat().split('.')[0]+'.000Z'
       datecompleted=datetime.now().isoformat().split('.')[0]+'.000Z'
       payload=create_modulegrade_payload(user_create["data"]["id"],courseid,moduleid,datecompleted,datesuccess,datestarted)
       data=get_data()
       data.clear()
       res,status=postrequest("users/"+user_create["data"]["id"]+"/userModuleGrade",payload)
       print(res)
       if status!=200:
          raise Exception
    except Exception as e:
         return False
    try:
        count=20
        while count:
            sleep(10)
            res_get,status_get=get_request("users/"+user_create["data"]["id"]+"/enrollments/"+res_enrollment["data"]["id"])
            if status!=200:
               raise Exception
            if res_get["data"]["attributes"]["state"]=="COMPLETED":
               return True
            count=count-1
        return True 
    except Exception as e:
        return False



@Report_generate
def test_createuser_enroll_complete_course_certificatebadge(testcase,instanceid,courseid,certinstance,certid,moduleid,badgeid):
    try:
       user=User()
       user.modify_email()
       user_payload=user.get_payload()
       user_create,status_user=postrequest("users/",user_payload)
       if status_user!=200:
          raise Exception
       data=get_data()
       data.clear()
       data["loId"]=certinstance.split('_')[0]
       data["loInstanceId"]=certinstance
       res_enrollment,status_enrollment=post_request_param("users/"+user_create["data"]["id"]+"/enrollments",data)
       if status_enrollment!=200:
          raise Exception
       datestarted=datetime.now().isoformat().split('.')[0]+'.000Z'
       datesuccess=datetime.now().isoformat().split('.')[0]+'.000Z'
       datecompleted=datetime.now().isoformat().split('.')[0]+'.000Z'
       payload=create_modulegrade_payload(user_create["data"]["id"],courseid,moduleid,datecompleted,datesuccess,datestarted)
       data=get_data()
       data.clear()
       res,status=postrequest("users/"+user_create["data"]["id"]+"/userModuleGrade",payload)
       if status!=200:
          raise Exception
    except Exception as e:
         return False
    try:
        count=20
        userbadgeid=user_create["data"]["id"]+"_"+badgeid+"_"+"CERTIFICATION"+"_"+certid
        while count:
            userbadge,status=get_request("users/"+user_create["data"]["id"]+"/userBadges/"+userbadgeid)
            print(userbadge)
            if status!=200:
               raise Exception
            if "dateAchieved" not in userbadge["data"]["attributes"]:
                sleep(3)
                count=count-1
            else:
               if userbadge["data"]["attributes"]["modelType"]=="learningObject" and userbadge["data"]["attributes"]["dateAchieved"].split('T')[0]==datetime.now().isoformat().split('T')[0]:
                      return True
               else:
                      return False
        return False
    except Exception as e:
        return False




if __name__=="__main__":
   Auto_init("ModuleGrade_certificate.csv")
   set_modulename(__file__)
   Env_init("286a1070-756a-4a15-bb52-17ab55da9a62","4813b9c1-db71-4093-96b8-9184575e14b8","67e1c8821e4ce427f0c71d9189ec7725")
   test_createuser_enroll_complete_certificate("Verify that learner can complete certificate by completing course associated with it","course:3102318_52983","3102318","certification:79091_112133","3764447_0")
   test_createuser_enroll_complete_course_certificatebadge("Verify that learner can achieve the certificate badge by completing the certificate","course:3102319_5770988","3102319","certification:79090_112132","79090","3764448_0","10690")
   Auto_close()