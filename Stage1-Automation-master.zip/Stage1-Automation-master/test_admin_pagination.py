from utility import *
from time import time
import json

@get_request
def get_request(*args):
    return args[1],args[2]


def pagination(total_data,page_limit,endpoint):
    obtained_data=0
    userdata=0
    data=get_data()
    data.clear()
    data["page[limit]"]=page_limit
    data["page[offset]"]=0
    has_next=True
    while has_next:
       res,status=get_request(endpoint)
       if status!=200:
           return False
       userdata=len(res["data"])
       obtained_data=obtained_data+userdata
       if "next" in res["links"]:
           data["page[offset]"]=res["links"]["next"].split('?')[1].split('&')[0].split('=')[1]
           if userdata!=page_limit:
              return False
           elif userdata==0:
              return False
           elif obtained_data>total_data:
              return False              
       else:
           if obtained_data==total_data:
              has_next=False
              break
           elif obtained_data!=total_data:
              return False
           elif userdata==0 and obtained_data!=total_data:
              return False
    return True

@Report_generate
def test_pagination(testcase,total_data,page_limit,endpoint):
    try:
       result=pagination(total_data,page_limit,endpoint)
       return result
    except Exception as e:
        return False


def pagination_cursor(total_data,page_limit,endpoint):
    obtained_data=0
    userdata=0
    data=get_data()
    data.clear()
    data["page[limit]"]=page_limit
    data["page[cursor]"]=''
    has_next=True
    while has_next:
       res,status=get_request(endpoint)
       if status!=200:
           return False
       userdata=len(res["data"])
       obtained_data=obtained_data+userdata
       if "next" in res["links"]:
           data["page[cursor]"]=res["links"]["next"].split('?')[1].split('&')[-1].split('=')[1]
           if userdata!=page_limit:
              return False
           elif userdata==0:
              return False
           elif obtained_data>total_data:
              return False
       else:
           if obtained_data==total_data:
              has_next=False
              break
           elif obtained_data!=total_data:
              return False
           elif userdata==0 and obtained_data!=total_data:
              return False
    return True


@Report_generate
def test_pagination_cursor(testcase,total_data,page_limit,endpoint):
    try:
       result=pagination_cursor(total_data,page_limit,endpoint)
       return result
    except Exception as e:
        return False

          
if __name__=="__main__":
   Auto_init("Adminside_pagination.csv")
   set_modulename(__file__)
   Env_init("6e2ecee3-301c-4257-914c-2601ab508e06","673815e3-0753-4aad-992f-3c68d159c59a","16ea3d944c0c8a290d4cdf774880d59a")
   test_pagination("Test the pagination related to external profile with page limit 10",23,10,"externalProfiles")
   test_pagination("Test the pagination related to external profile with page limit 7",23,7,"externalProfiles")
   test_pagination("Test the pagination related to external profile with page limit 5",23,5,"externalProfiles")
   test_pagination("Test the pagination related to external profile users with page limit 10", 24, 10, "externalProfiles/2664/users")
   test_pagination("Test the pagination related to external profile users with page limit 7", 24, 7, "externalProfiles/2664/users")
   test_pagination("Test the pagination related to external profile users with page limit 5", 24, 5, "externalProfiles/2664/users")
   test_pagination("Test the pagination related to usergroup with page limit 10",44,10,"userGroups")
   test_pagination("Test the pagination related to usergroup with page limit 7",44,7,"userGroups")
   test_pagination("Test the pagination related to usergroup with page limit 5",44,5,"userGroups")
   test_pagination("Test the pagination related to skill with page limit 10",25,10, "skills")
   test_pagination("Test the pagination related to skill with page limit 6", 25,6, "skills")
   test_pagination("Test the pagination related to skill with page limit 3", 25,3, "skills")
   test_pagination("Test the pagination related to userskill with page limit 10", 27, 10, "users/5396939/userSkills")
   test_pagination("Test the pagination related to userskill with page limit 6", 27,6,"users/5396939/userSkills")
   test_pagination("Test the pagination related to userskill with page limit 4", 27,4,"users/5396939/userSkills")
   test_pagination("Test the pagination related to badge with page limit 10",22,10, "badges")
   test_pagination("Test the pagination related to badge with page limit 6",22,6, "badges")
   test_pagination("Test the pagination related to badge with page limit 5",22,5, "badges")
   Auto_close()
