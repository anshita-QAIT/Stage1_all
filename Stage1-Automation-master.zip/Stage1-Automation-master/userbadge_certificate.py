from utility import *
from time import time
import json

#bapan12q@gmail.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test_learnerbadge_Certificate_include(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.subLOs"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       include=[]
       for obj in res["included"]:
          include.append(obj["id"])
       for id in args:
          if id not in include:
             return False
       return True
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_Certificate_include_parellel_query(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model,learner,badge"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       include=[]
       for obj in res["included"]:
          include.append(obj["id"])
       for id in args:
          if id not in include:
             return False
       return True
    except Exception as e:
        return False


@Report_generate
def test_learnerbadge_Certificate_enrollment_include(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.enrollment"
    data["ids"] =userbadgeid
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       include=[]
       for obj in res["included"]:
          include.append(obj["id"])
       for id in args:
          if id not in include:
             return False
       return True
    except Exception as e:
        return False


@Report_generate
def test_learnerbadge_Certificate_enrollment_include_id(testcase,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.enrollment"
    data["ids"] =userbadgeid
    try:
      url="users/"+userbadgeid.split('_')[0]+"/userBadges/"+userbadgeid
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       include=[]
       for obj in res["included"]:
          include.append(obj["id"])
       for id in args:
          if id not in include:
             return False
       return True
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_Certificate_include_id(testcase,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.subLOs"
    data["ids"] =userbadgeid 
    try:
      url="users/"+userbadgeid.split('_')[0]+"/userBadges/"+userbadgeid
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       include=[]
       for obj in res["included"]:
          include.append(obj["id"])
       for id in args:
          if id not in include:
             return False
       return True
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_Certificate_enrollment_model(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.enrollment"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
      for obj in res["included"]:
          if obj["type"]=="learningObjectInstanceEnrollment":
             if obj["attributes"]["state"]==args[0] and obj["attributes"]["progressPercent"]==args[1] and obj["attributes"]["dateStarted"]==args[2] and obj["attributes"]["dateCompleted"]==args[3]:
                  return True
             else:
                  return False
      return False
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_Certificate_enrollment_model_id(testcase,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.enrollment"
    try:
      url="users/"+userbadgeid.split('_')[0]+"/userBadges/"+userbadgeid
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
      for obj in res["included"]:
          if obj["type"]=="learningObjectInstanceEnrollment":
             if obj["attributes"]["state"]==args[0] and obj["attributes"]["progressPercent"]==args[1] and obj["attributes"]["dateStarted"]==args[2] and obj["attributes"]["dateCompleted"]==args[3]:
                  return True
             else:
                  return False
      return False
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_sublo_model(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.subLOs"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       for obj in res["included"]:
          if obj["type"]=="learningObject" and obj["id"].split(':')[0]=="course":
             if obj["relationships"]["enrollment"]["data"]["id"]==args[0]:
                   return True
             else:
                   return False
       return False
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_sublo_model_id(testcase,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.subLOs"
    data["ids"] =userbadgeid 
    try:
      url="users/"+userbadgeid.split('_')[0]+"/userBadges/"+userbadgeid
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       for obj in res["included"]:
          if obj["type"]=="learningObject" and obj["id"].split(':')[0]=="course":
             if obj["relationships"]["enrollment"]["data"]["id"]==args[0]:
                   return True
             else:
                   return False
       return False
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_course_skill_model(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.skills"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       for obj in res["included"]:
          if obj["type"]=="learningObjectSkill":
             if obj["attributes"]["credits"]==args[0] and obj["relationships"]["skillLevel"]["data"]["id"]==args[1]:
                return True
             else:
                return False
       return False
    except Exception as e:
        return False


@Report_generate
def test_learnerbadge_badge_model_learner_include(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "badge,learner,model"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       include=[]
       for obj in res["included"]:
          include.append(obj["id"])
       for id in args:
          if id not in include:
             return False
       return True
    except Exception as e:
        return False


@Report_generate
def test_learnerbadge_badge_model_learner_include_id(testcase,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "badge,learner,model"
    data["ids"] =userbadgeid 
    try:
      url="users/"+userbadgeid.split('_')[0]+"/userBadges/"+userbadgeid
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       include=[]
       for obj in res["included"]:
          include.append(obj["id"])
       for id in args:
          if id not in include:
             return False
       return True
    except Exception as e:
        return False





if __name__=="__main__":
   Auto_init("userbadge_certificate.csv")
   set_modulename(__file__)
   Env_init("7ce96f5a-2c07-4b93-a0e1-f025f8fa0aa9","5d084f8a-cdf3-480a-9dbb-5d24baa49da4","89900945b81d421f610f4ed2debd925f")
   test_learnerbadge_Certificate_include("Test the include objects of the certificate badge",7107207,"7107207_7305_CERTIFICATION_66866","course:2037190","certification:66866")
   test_learnerbadge_Certificate_include_id("Test the include objects certificate","7107207_7305_CERTIFICATION_66866","course:2037190","certification:66866")
   test_learnerbadge_Certificate_enrollment_include("Test the objects in include array for include=model.enrollment",7107207,"7107207_7305_CERTIFICATION_66866","certification:66866","certification:66866_100355_7107207")
   test_learnerbadge_Certificate_enrollment_model("Test the enrollment object certificate",7107207,"7107207_7305_CERTIFICATION_66866","COMPLETED",100,"2020-02-17T02:18:00.000Z","2020-02-17T02:18:00.000Z")
   test_learnerbadge_Certificate_enrollment_include_id("Test the include objects for userbadge obtained by id","7107207_7305_CERTIFICATION_66866","certification:66866","certification:66866_100355_7107207")
   test_learnerbadge_Certificate_enrollment_model_id("Test the enrollment object in include array by id","7107207_7305_CERTIFICATION_66866","COMPLETED",100,"2020-02-17T02:18:00.000Z","2020-02-17T02:18:00.000Z")
   test_learnerbadge_sublo_model("Test the enrollment associated with the sublo",7107207,"7107207_7305_CERTIFICATION_66866","course:2037190_3717119_7107207")
   test_learnerbadge_sublo_model_id("Test the sublo model object include array by id","7107207_7305_CERTIFICATION_66866","course:2037190_3717119_7107207")
   test_learnerbadge_Certificate_include_parellel_query("Test the parellel query for the include=model,learner,badge",7107207,"7107207_7305_CERTIFICATION_66866","7305","7107207","certification:66866")
   test_learnerbadge_badge_model_learner_include_id("Test the parellel query for the include=model,learner,badge by id","7107207_7305_CERTIFICATION_66866","7305","7107207","certification:66866")
   Auto_close()
