from utility import *
from time import time
import json

#taga@faga.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test_tag_Cerificate(testcase,tag_value,*args):
    data = get_data()
    data.clear()
    data["filter.tagName"] = tag_value
    data["page[offset]"] =0
    data["page[limit]"]=10
    data["filter.loTypes"] = "certification"
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       cid=[]
       for obj in res["data"]:
          if obj["attributes"]["tags"][0]!=tag_value:
               return False
          cid.append(obj["id"])
       for i in args:
          if i not in cid:
            return False
       if len(cid)!=5:
          return False
       return True
    except Exception as e:
        return False


@Report_generate
def test_2tag_Course(testcase,tag_value1,tag_value2,*args):
    data = get_data()
    data.clear()
    data["filter.tagName"] = tag_value1+","+tag_value2
    data["filter.loTypes"] ="certification"
    data["page[limit]"]=10
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       cid=[]
       for obj in res["data"]:
          if obj["attributes"]["tags"][0]==tag_value1 or obj["attributes"]["tags"][0]==tag_value2:
               pass
          else:
              return False
          cid.append(obj["id"])
       for i in args:
          if i not in cid:
            return False
       if len(cid)!=10:
          return False
       return True
    except Exception as e:
        return False






if __name__=="__main__":
   Auto_init("Tag_Certificate.csv")
   set_modulename(__file__)
   Env_init("7a5fca40-1013-4166-bb92-cee58a43a980","54cda52b-f078-42e3-8a75-ad3b605166f7","31cafab8def2491b6bd0395dd72974c8")
   test_tag_Cerificate("Test the tag CER1 associated with certificate","CER1","certification:67270","certification:67269","certification:67267","certification:67268","certification:67271")
   test_tag_Cerificate("Test the tag CER2 associated with certificate","CER2","certification:67272","certification:67275","certification:67273","certification:67276","certification:67274")
   test_tag_Cerificate("Test the tag CER3 associated with certificate","CER3","certification:67281","certification:67278","certification:67280","certification:67282","certification:67279")
   test_tag_Cerificate("Test the tag CER4 associated with certificate","CER4","certification:67285","certification:67286","certification:67287","certification:67284","certification:67283")
   test_2tag_Course("Test the CER1/CER2 tag associated with the certificate","CER1","CER2","certification:67270","certification:67269","certification:67267","certification:67268","certification:67271","certification:67272","certification:67273","certification:67274","certification:67275","certification:67276")
   test_2tag_Course("Test the CER2/CER3 tag associated with the certificate","CER2","CER3","certification:67281","certification:67272","certification:67275","certification:67273","certification:67276","certification:67274","certification:67278","certification:67280","certification:67282","certification:67279")
   test_2tag_Course("Test the CER3/CER4 tag associated with the certificate","CER3","CER4","certification:67281","certification:67285","certification:67286","certification:67287","certification:67280","certification:67282","certification:67279","certification:67278","certification:67284","certification:67283")
   Auto_close()
