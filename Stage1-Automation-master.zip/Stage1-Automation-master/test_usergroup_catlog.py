from utility import *
from time import time
import json

#bapan12q@gmail.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test_usergroup_catalog(testcase,catalogid,*args):
    data = get_data()
    data.clear()
    hasnext=True
    request_list=[]
    usergroup_list=[]
    data["page[offset]"] = 0
    data["page[limit]"] = 10
    data["catalogId"] = catalogid
    try:
     while hasnext:
         res,stat=get_request("userGroups")
         if stat==200:
             request_list.append(res)
         if "next" in res["links"]:
             data["page[offset]"]=int(res["links"]["next"].split('?')[1].split('&')[0].split('=')[1])
             hasnext=True
         else:
             hasnext=False
     for res in request_list:
         for obj in res["data"]:
             usergroup_list.append(obj["id"])
     for obj in args:
         if obj not in usergroup_list:
             return False
         return True
    except Exception as e:
        return False


@Report_generate
def test_usergroup_catalog_customgroup(testcase,catalogid,*args):
    data = get_data()
    data.clear()
    hasnext=True
    request_list=[]
    usergroup_list=[]
    data["filter.readOnly"]="false"
    data["page[offset]"] = 0
    data["page[limit]"] = 3
    data["catalogId"] = catalogid
    try:
     while hasnext:
         res,stat=get_request("userGroups")
         if stat==200:
             request_list.append(res)
         if "next" in res["links"]:
             data["page[offset]"]=int(res["links"]["next"].split('?')[1].split('&')[0].split('=')[1])
             hasnext=True
         else:
             hasnext=False
     for res in request_list:
         for obj in res["data"]:
             usergroup_list.append(obj["id"])
     for obj in args:
         if obj not in usergroup_list:
             return False
         return True
    except Exception as e:
        return False


@Report_generate
def test_usergroup_catalog_builtingroup(testcase,catalogid,*args):
    data = get_data()
    data.clear()
    hasnext=True
    request_list=[]
    usergroup_list=[]
    data["filter.readOnly"]="true"
    data["page[offset]"] = 0
    data["page[limit]"] = 1
    data["catalogId"] = catalogid
    try:
     while hasnext:
         res,stat=get_request("userGroups")
         if stat==200:
             request_list.append(res)
         if "next" in res["links"]:
             data["page[offset]"]=int(res["links"]["next"].split('?')[1].split('&')[0].split('=')[1])
             hasnext=True
         else:
             hasnext=False
     for res in request_list:
         for obj in res["data"]:
             usergroup_list.append(obj["id"])
     for obj in args:
         if obj not in usergroup_list:
             return False
     return True
    except Exception as e:
        return False


@Report_generate
def test_catalog_IntegrationAdmin(testcase,catalogid,ugid,ugname,readonly):
    data = get_data()
    data.clear()
    data["catalogId"] = catalogid
    try:
        res, status = get_request("userGroups")
        if status != 200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res["data"][0]["id"]==ugid and res["data"][0]["attributes"]["name"]==ugname and res["data"][0]["attributes"]["readOnly"]==readonly:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_catalog_authors(testcase,catalogid,ugid,ugname,readonly):
    data = get_data()
    data.clear()
    data["catalogId"] = catalogid
    try:
        res, status = get_request("userGroups")
        if status != 200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res["data"][0]["id"]==ugid and res["data"][0]["attributes"]["name"]==ugname and res["data"][0]["attributes"]["readOnly"]==readonly:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_usergroups_by_id(testcase,ugid,*args):
    data = get_data()
    data.clear()
    try:
        str1="userGroups/"+str(ugid)
        res, status = get_request(str1)
        if status != 200:
            raise Exception
    except Exception as e:
        return False
    try:
        if res["data"]["id"]==args[0] and res["data"]["attributes"]["name"]==args[1] and res["data"]["attributes"]["readOnly"]==args[2] and res["data"]["attributes"]["description"]==args[3] and res["data"]["attributes"]["state"]==args[4]:
            return True
        else:
            return False
    except Exception as e:
        return False




if __name__=="__main__":
   Auto_init("usergroup_test.csv")
   set_modulename(__file__)
   Env_init("9b7dddab-0ec6-432c-9c66-e5dfdd063001","30e8e21f-17b2-4fd4-9950-f31051caa152","a22ef46a8e99944c056022aaa7048e8e")
   test_usergroup_catalog("Test the usergroups associated with the catalog",13812,"985934","985933","985935","985954","985946","985947","985948","985950","985951","985949","985952","985953","985944","985937")
   test_usergroup_catalog_customgroup("Test the custom user group associated with the catalog",13812,"985954","985946","985947","985948","985950","985951","985949","985952","985953","985944")
   test_usergroup_catalog_builtingroup("Test the built in usergroup associated with the catalog",13812,"985934","985933","985935","985937")
   test_catalog_authors("Test the catalog associated with all author",13809,"985933","All Authors",True)
   test_catalog_IntegrationAdmin("Test the catalog associated with Integration Admin",13810,"985944","Integration Admin",False)
   test_usergroups_by_id("Test the all admin usergroup in prime account",985934,"985934","All Admins",True,"All administrators for this account","Active")
   test_usergroups_by_id("Test the all author usergroup in prime account",985933,"985933","All Authors",True,"All users in this account who have the Author role","Active")
   test_usergroups_by_id("Test the Instructor user group in Prime accounr",986052,"986052","Instructors",False,"DESSS","Active")
   Auto_close()