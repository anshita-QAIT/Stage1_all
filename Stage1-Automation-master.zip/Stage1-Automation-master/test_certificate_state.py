from utility import *
from time import time
import json

#bapan4536@gmail.com
#acc:5738
#Learner#12

@get_request
def get_catalog_lo(*args):
    return args[1]

@get_request
def get_enrollment_id(*args):
    return args[1]


@Report_generate
def test_lo_catalog(testcase,state,catalogid,count):
    enrollment=[]
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.catalogIds"]=catalogid
       data["filter.loTypes"]="certification"
       data["filter.learnerState"]=state
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             enrollment.append(obj["relationships"]["enrollment"]["data"]["id"])
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break 
       for id in  enrollment: 
           str1="enrollments/"+str(id)
           resp=get_enrollment_id(str1)
           if resp["data"]["attributes"]["state"]!=state.upper():
              return False
       if len(enrollment)!=count:
           return False
       return True           
    except Exception as e:
       return False


@Report_generate
def test_lo_catalog_started_completed(testcase,catalogid,count):
    enrollment=[]
    test=False
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.loTypes"]="certification"
       data["filter.catalogIds"]=catalogid
       data["filter.learnerState"]="completed,started"
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             enrollment.append(obj["relationships"]["enrollment"]["data"]["id"])
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break
       for id in  enrollment:
           str1="enrollments/"+str(id)
           resp=get_enrollment_id(str1)
           if resp["data"]["attributes"]["state"]=="COMPLETED" or resp["data"]["attributes"]["state"]=="STARTED":
               test=True
           else:
               test=False
               return False
       if len(enrollment)!=count:
           return False
       return test
    except Exception as e:
       return False


@Report_generate
def test_lo_catalog_enrolled_completed(testcase,catalogid,count):
    enrollment=[]
    test=False
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.loTypes"]="certification"
       data["filter.catalogIds"]=catalogid
       data["filter.learnerState"]="completed,enrolled"
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             enrollment.append(obj["relationships"]["enrollment"]["data"]["id"])
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break
       for id in  enrollment:
           str1="enrollments/"+str(id)
           resp=get_enrollment_id(str1)
           if resp["data"]["attributes"]["state"]=="COMPLETED" or resp["data"]["attributes"]["state"]=="ENROLLED":
               test=True
           else:
               test=False
               return False
       if len(enrollment)!=count:
           return False
       return test
    except Exception as e:
       return False


@Report_generate
def test_lo_catalog_enrolled_started(testcase,catalogid,count):
    enrollment=[]
    test=False
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.loTypes"]="certification"
       data["filter.catalogIds"]=catalogid
       data["filter.learnerState"]="enrolled,started"
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             enrollment.append(obj["relationships"]["enrollment"]["data"]["id"])
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break
       for id in  enrollment:
           str1="enrollments/"+str(id)
           resp=get_enrollment_id(str1)
           if resp["data"]["attributes"]["state"]=="STARTED" or resp["data"]["attributes"]["state"]=="ENROLLED":
               test=True
           else:
               test=False
               return False
       if len(enrollment)!=count:
           return False
       return test
    except Exception as e:
       return False


@Report_generate
def test_lo_catalog_enrolled_started_completed(testcase,catalogid,count):
    enrollment=[]
    test=False
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.loTypes"]="certification"
       data["filter.catalogIds"]=catalogid
       data["filter.learnerState"]="started,completed,enrolled"
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             enrollment.append(obj["relationships"]["enrollment"]["data"]["id"])
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break
       for id in  enrollment:
           str1="enrollments/"+str(id)
           resp=get_enrollment_id(str1)
           if resp["data"]["attributes"]["state"]=="STARTED" or resp["data"]["attributes"]["state"]=="ENROLLED" or resp["data"]["attributes"]["state"]=="COMPLETED":
               test=True
           else:
               test=False
               return False
       if len(enrollment)!=count:
           return False
       return test
    except Exception as e:
       return False

@Report_generate
def test_lo_catalog_notenrolled(testcase,state,catalogid,count):
    enrollment=[]
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.loTypes"]="certification"
       data["filter.catalogIds"]=catalogid
       data["filter.learnerState"]=state
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             if "enrollment" not in obj["relationships"].keys():
                enrollment.append(obj["id"])
             else:
                return False
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break 
       if len(enrollment)!=count:
           return False
       return True           
    except Exception as e:
       return False

if __name__=="__main__":
   Auto_init("learnerstate_Certificate.csv")
   set_modulename(__file__)
   Env_init("3c5c4d80-9947-4eaa-ac7d-9f33f8c9fbaf","95065a79-c090-4a6e-ae4e-8544d90ed82a","b7ebf30a2f54851b25f7262f52625135")
   test_lo_catalog("Test the completed state of the certificate related to catalog","completed",18713,4)
   test_lo_catalog("Test the enrolled state of the certificate related to catalog","enrolled",18713,3)
   test_lo_catalog("Test the enrolled state of the certificate related to catalog","started",18713,3)
   test_lo_catalog_started_completed("Test the started and completed state of the Certificate related to catalog",18713,7)
   test_lo_catalog_enrolled_completed("Test the completed and enrolled state of the certificate",18713,7)
   test_lo_catalog_enrolled_started("Test the enrolled and started status of certificate",18713,6)
   test_lo_catalog_enrolled_started_completed("Test the enrolled ,started,completed state of the certificate",18713,10)
   Auto_close()


    





