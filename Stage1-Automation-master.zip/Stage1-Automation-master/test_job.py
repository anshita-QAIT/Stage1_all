from utility import *
import time
import json

#bapan12q@gmail.com
#Learner#12
#acc:5831

######################################################################### UTILITY METHODS ########################################

badge={
    "data": {
   "type": "job",
   "attributes": {
     "description": "Desc",
     "jobType": "generateUserBadge",
     "payload":{
         "userBadgeId": "4401855_6857_COURSE_1999078"
     }
   }
 }
}

def set_badge(str1):
   badge["data"]["attributes"]["payload"]["userBadgeId"]=str1


LTscript={
    "data": {
   "type": "job",
   "attributes": {
     "description": "Desc",
     "jobType": "generateLearnerTranscript"
   }
 }
}



course={
  "data": {
  "type": "job",
  "attributes": {
    "description": "Desc",
    "jobType": "generateQuizReport",
    "payload":{
       "courseId": "course:1",                       
       "courseInstanceId" : "course:1_2"
     }
   }
  }
}

def set_course(str1,str2):
    course["data"]["attributes"]["payload"]["courseId"]=str1
    course["data"]["attributes"]["payload"]["courseInstanceId"]=str2
    


certification={
    "data": {
   "type": "job",
   "attributes": {
     "description": "Desc",
     "jobType": "generateQuizReport",
     "payload":{
         "courseId": "course:1",                 
         "certificationId" : "certification:2" 
     }
   }
 }
}

def set_certificate(str1,str2):
    certification["data"]["attributes"]["payload"]["courseId"]=str1
    certification["data"]["attributes"]["payload"]["certificationId"]=str2



LProgram={
    "data": {
   "type": "job",
   "attributes": {
     "description": "Desc",
     "jobType": "generateQuizReport",
     "payload":{
         "courseId": "course:1",                                                   
         "learningProgramInstanceId" : "learningProgram:2_3"  
     }
   }
 }
}

def set_learningprogram(str1,str2):
    LProgram["data"]["attributes"]["payload"]["courseId"]=str1
    LProgram["data"]["attributes"]["payload"]["learningProgramInstanceId"]=str2


# POST request function for testing basic functionality of POST method.
@post_request_payload
def post_job(*args):
    return args[2]


# GET request function to retrieve the user by id.
@get_request
def get_job(*args):
    return args[1]

@get_request
def get_job_id(*args):
    return args[1]

################################################################# VALIDATION METHOD ##############################################
def get_job_id(id):
    str1="jobs/"+str(id)
    res=get_job(str1)
    return res
   

@Report_generate
def test_create_job_course_badge(testcase,badgestr):
    count=20
    try:
        set_badge(badgestr)
        res=post_job("jobs",json.dumps(badge))
        id=res["data"]["id"]
        while count:
           res = get_job_id(id)
           if res["data"]["attributes"]["status"]["code"]=="Completed":
                return True
           else:
                time.sleep(10)
           count=count-1
           if count==0:
               return False
    except Exception as e:
       return False
    
    
    
@Report_generate
def test_create_job_LP_badge(testcase,badgestr):
    count=20
    try:
        set_badge(badgestr)
        res=post_job("jobs",json.dumps(badge))
        id=res["data"]["id"]
        while count:
           res=get_job_id(id)
           if res["data"]["attributes"]["status"]["code"]=="Completed":
                return True
           else:
                time.sleep(10)
           count=count-1
           if count==0:
              return False
    except Exception as e:
       return False


@Report_generate
def test_create_job_certificate_badge(testcase,badgestr):
    count=20
    try:
        set_badge(badgestr)
        res=post_job("jobs",json.dumps(badge))
        id=res["data"]["id"]
        while count:
           res=get_job_id(id)
           if res["data"]["attributes"]["status"]["code"]=="Completed":
                return True
           else:
                time.sleep(10)
           count=count-1
           if count==0:
              return False
    except Exception as e:
       return False


@Report_generate
def test_create_job_skill_badge(testcase,badgestr):
    count=20
    try:
        set_badge(badgestr)
        res=post_job("jobs",json.dumps(badge))
        id=res["data"]["id"]
        while count:
           res=get_job_id(id)
           if res["data"]["attributes"]["status"]["code"]=="Completed":
                return True
           else:
                time.sleep(10)
           count=count-1
           if count==0:
              return False
    except Exception as e:
       return False


@Report_generate
def test_create_job_learnertranscript(testcase):
    count=20
    try:
        res=post_job("jobs",json.dumps(LTscript))
        id=res["data"]["id"]
        while count:
           res=get_job_id(id)
           if res["data"]["attributes"]["status"]["code"]=="Completed":
                return True
           else:
                time.sleep(10)
           count=count-1
           if count==0:
              return False
    except Exception as e:
       return False
    


@Report_generate
def test_create_job_course_quizreport(testcase,str1,str2):
    count=20
    try:
        set_course(str1,str2)
        res=post_job("jobs",json.dumps(course))
        id=res["data"]["id"]
        while count:
           res=get_job_id(id)
           if res["data"]["attributes"]["status"]["code"]=="Completed":
                return True
           else:
                time.sleep(10)
           count=count-1
           if count==0:
              return False
    except Exception as e:
       return False



@Report_generate
def test_create_job_LP_quizreport(testcase,str1,str2):
    count=20
    try:
        set_learningprogram(str1,str2)
        res=post_job("jobs",json.dumps(LProgram))
        id=res["data"]["id"]
        while count:
           res=get_job_id(id)
           if res["data"]["attributes"]["status"]["code"]=="Completed":
                return True
           else:
                time.sleep(10)
           count=count-1
           if count==0:
              return False
    except Exception as e:
       return False
   


@Report_generate
def test_create_job_certificate_quizreport(testcase,str1,str2):
    count=20
    try:
        set_certificate(str1,str2)
        res=post_job("jobs",json.dumps(certification))
        id=res["data"]["id"]
        while count:
           res=get_job_id(id)
           if res["data"]["attributes"]["status"]["code"]=="Completed":
                return True
           else:
                time.sleep(10)
           count=count-1
           if count==0:
              return False
    except Exception as e:
        return False
   
 
###################################################### TEST SCRIPTS ############################################################

if __name__ == "__main__":
    Auto_init("Jobs.csv")
    set_modulename(__file__)
    #Learner Badge
    Env_init("7ce96f5a-2c07-4b93-a0e1-f025f8fa0aa9","5d084f8a-cdf3-480a-9dbb-5d24baa49da4","89900945b81d421f610f4ed2debd925f")
    test_create_job_course_badge("Test the course badge job status","7107207_7306_COURSE_2037181")
    test_create_job_LP_badge("Test the LP badge job status","7107207_7308_LP_40293")
    test_create_job_certificate_badge("Test the certificate badge job status","7107207_7305_CERTIFICATION_66866")
    test_create_job_skill_badge("Test the skill badge job status","7107207_7308_COMPETENCY_43286_1")
    test_create_job_learnertranscript("Test the learner transcript job status")
    Env_init("77361b46-88da-4921-b6cc-88b70fb11076","debd6b36-b247-41c7-8367-6f375fa3bea6","f9290c1073b58ad2c53a113433f87c80")
    test_create_job_certificate_quizreport("Test the completed state of the certificate quiz report","course:2037729","certification:66909")
    test_create_job_LP_quizreport("Test the completed state of the LP quiz","course:2037728","learningProgram:40326_47281")
    test_create_job_course_quizreport("Test the completed state of the course quiz","course:2037727","course:2037727_3717736")
    Auto_close()