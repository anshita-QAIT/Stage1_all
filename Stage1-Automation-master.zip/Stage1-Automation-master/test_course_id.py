from utility import *


@get_request
def get_lo(*args):
    return args[1]

@Report_generate
def test_course_include_instanceloresourceresource(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_loresources(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    loresource_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectResource":
                loresource_id.append(obj["id"])
        for obj in args:
            if obj not in loresource_id:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_course_include_resources(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    resource_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="resource":
                resource_id.append(obj["id"])
        for obj in args:
            if obj not in resource_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_instances(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    instance_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance":
                instance_id.append(obj["id"])
        for obj in args:
            if obj not in instance_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_instancebadge(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.badge"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_badge(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.badge"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    badge_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="badge":
                badge_id.append(obj["id"])
        for obj in args:
            if obj not in badge_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_instancesl1FeedbackInfo(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.l1FeedbackInfo"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_1FeedbackInfo(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances.l1FeedbackInfo"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    feedback_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="feedbackInfo":
                feedback_id.append(obj["id"])
        for obj in args:
            if obj not in feedback_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_skillsskillLevelbadge(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "skills.skillLevel.badge"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_skillbadge(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "skills.skillLevel.badge"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    badge_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="badge":
                 badge_id.append(obj["id"])
        for obj in args:
            if obj not in badge_id:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_course_include_skilllevel(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "skills.skillLevel.badge"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    skilllevel_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="skillLevel":
                 skilllevel_id.append(obj["id"])
        for obj in args:
            if obj not in skilllevel_id:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_course_include_courseskill(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "skills.skillLevel.badge"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    courseskill_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectSkill":
                 courseskill_id.append(obj["id"])
        for obj in args:
            if obj not in courseskill_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_prerequisiteinstance(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "prerequisiteLOs.instances"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_prerequisiteskills(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "prerequisiteLOs.skills"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_course_include_prerequisiteauthor(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "prerequisiteLOs.authors"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_skillsskillLevelskilllevels(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "skills.skillLevel.skill.levels"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_skillobjects(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "skills.skillLevel.skill.levels"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    loskill_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="skill":
                loskill_id.append(obj["id"])
        for obj in args:
            if obj not in loskill_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_loskill(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "skills.skillLevel.skill.levels"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    loskill_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectSkill":
                loskill_id.append(obj["id"])
        for obj in args:
            if obj not in loskill_id:
                return False
        return True
    except Exception as e:
        return False



@Report_generate
def test_course_include_skilllevelobjects(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "skills.skillLevel.skill.levels"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    skilllevel_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="skillLevel":
                skilllevel_id.append(obj["id"])
        for obj in args:
            if obj not in skilllevel_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_supplimentarylo(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "supplementaryLOs.instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_supplimentaryloobjects(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "supplementaryLOs.instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    supplimentrylo_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObject" and obj["id"].split(':')[0]=="jobAid":
                supplimentrylo_id.append(obj["id"])
        for obj in args:
            if obj not in supplimentrylo_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_jobaidloresource(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "supplementaryLOs.instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    loresource_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectResource":
                loresource_id.append(obj["id"])
        for obj in args:
            if obj not in loresource_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_jobaidloresource(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "supplementaryLOs.instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    loresource_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectResource":
                loresource_id.append(obj["id"])
        for obj in args:
            if obj not in loresource_id:
                return False
        return True
    except Exception as e:
        return False



@Report_generate
def test_course_include_jobaidresource(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "supplementaryLOs.instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    resource_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="resource":
                resource_id.append(obj["id"])
        for obj in args:
            if obj not in resource_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_jobaidinstance(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "supplementaryLOs.instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    jobaidinstance_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance":
                jobaidinstance_id.append(obj["id"])
        for obj in args:
            if obj not in jobaidinstance_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_jobaidinstance(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "supplementaryLOs.instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    jobaidinstance_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance":
                jobaidinstance_id.append(obj["id"])
        for obj in args:
            if obj not in jobaidinstance_id:
                return False
        return True
    except Exception as e:
        return False



@Report_generate
def test_course_include_supplimentaryresource(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "supplementaryResources,instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_supplimentaryresourceobject(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "supplementaryResources,instances.loResources.resources"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    supplimentaryresource_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="resource" and obj["attributes"]["contentType"]=="Attachment":
                supplimentaryresource_id.append(obj["id"])
        for obj in args:
            if obj not in supplimentaryresource_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_enrollmentinstance(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loInstance"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_course_include_enrolledinstance(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loInstance"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    loinstance_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstance":
                loinstance_id.append(obj["id"])
        for obj in args:
            if obj not in loinstance_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_enrolledobject(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loInstance"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    enrolled_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstanceEnrollment":
                enrolled_id.append(obj["id"])
        for obj in args:
            if obj not in enrolled_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_enrollmentlearnerbadge(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.learnerBadge.badge"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_enrolledobjectlearnerbadge(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.learnerBadge.badge"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    enrolled_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectInstanceEnrollment":
                enrolled_id.append(obj["id"])
        for obj in args:
            if obj not in enrolled_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_learnerbadge(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.learnerBadge.badge"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    userbadge_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="userBadge":
                userbadge_id.append(obj["id"])
        for obj in args:
            if obj not in userbadge_id:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_course_include_badgeenrollement(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.learnerBadge.badge"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    badge_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="badge":
                badge_id.append(obj["id"])
        for obj in args:
            if obj not in badge_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_enrollmentlearnerbadgelearner(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.learnerBadge.learner"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_learnerenrollment(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.learnerBadge.learner"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    user_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="user":
                user_id.append(obj["id"])
        for obj in args:
            if obj not in user_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_enrollmentmodelinstances(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.learnerBadge.model.instances"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_course_include_enrollmentmodel(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.learnerBadge.model"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False

@Report_generate
def test_course_include_enrollmenloresourcegrades(Testcase,course_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment.loResourceGrades.loResource"
    try:
        str1="learningObjects/"+str(course_id)
        req = get_lo(str1)
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False



if __name__=="__main__":
    Auto_init("Course_include_id.csv")
    set_modulename(__file__)
    Env_init("e683c33a-dc19-4657-83c1-80c063e7f852", "c66574a7-bdae-4301-9fd8-f6b53ab7c71f","427a14964641d857c974fddfcc83e8b5")
    #######################  include=instance.loresources.resources ##############################################################
    test_course_include_instanceloresourceresource("Test the objects in include array for include=instance.loresources.resources","course:2022578","course:2022578_3701730","course:2022578_3701731","course:2022578_3701732","580662_1_en-US","course:2022578_3701731_2659937_0_resource","course:2022578_3701732_2659937_0_resource","580668_2_en-US","580667_1_en-US","course:2022578_3701732_2659940_0_resource","course:2022578_3701730_2659937_0_resource","course:2022578_3701730_2659940_0_resource","course:2022578_3701731_2659940_0_resource","course:2022578_3701730_2659936_0","course:2022578_3701731_2659936_0","course:2022578_3701732_2659936_0","course:2022578_3701730_2659937_0","course:2022578_3701731_2659937_0","course:2022578_3701732_2659937_0","course:2022578_3701730_2659938_0","course:2022578_3701731_2659938_0","course:2022578_3701732_2659938_0","course:2022578_3701730_2659939_0","course:2022578_3701731_2659939_0","course:2022578_3701732_2659939_0","course:2022578_3701730_2659940_0","course:2022578_3701731_2659940_0","course:2022578_3701732_2659940_0")
    test_course_include_loresources("Test the loresources in the include array","course:2022578","course:2022578_3701732_2659940_0","course:2022578_3701731_2659940_0","course:2022578_3701730_2659940_0","course:2022578_3701732_2659939_0","course:2022578_3701731_2659939_0","course:2022578_3701730_2659939_0","course:2022578_3701732_2659938_0","course:2022578_3701731_2659938_0","course:2022578_3701730_2659938_0","course:2022578_3701732_2659937_0","course:2022578_3701731_2659937_0","course:2022578_3701730_2659937_0","course:2022578_3701732_2659936_0","course:2022578_3701731_2659936_0","course:2022578_3701730_2659936_0")
    test_course_include_resources("Test the resources associated with the course modules","course:2022578","580662_1_en-US","course:2022578_3701731_2659937_0_resource","course:2022578_3701732_2659937_0_resource","580668_2_en-US","580667_1_en-US","course:2022578_3701732_2659940_0_resource","course:2022578_3701730_2659937_0_resource","course:2022578_3701730_2659940_0_resource","course:2022578_3701731_2659940_0_resource")
    test_course_include_instances("Test the instances associated with the course","course:2022578","course:2022578_3701730","course:2022578_3701731","course:2022578_3701732")
    ###################### include=instance.badge #####################################################
    test_course_include_instancebadge("Test the objects in the include array ","course:2022578","course:2022578_3701730","course:2022578_3701731","course:2022578_3701732","7133","7136")
    test_course_include_badge("Test the badges associated with the course instance","course:2022578","7133","7136")
    ########################## include=instance.l1FeedbackInfo ##################################
    test_course_include_instancesl1FeedbackInfo("Test the objects in include array include=instances.l1FeedbackInfo","course:2022578","course:2022578_3701730","course:2022578_3701731","course:2022578_3701732","course:2022578_3701730_l1Feedback","course:2022578_3701732_l1Feedback","course:2022578_3701731_l1Feedback")
    test_course_include_1FeedbackInfo("Test the l1feedback id's in the include array","course:2022578","course:2022578_3701731_l1Feedback","course:2022578_3701732_l1Feedback","course:2022578_3701730_l1Feedback")
    ######################### include=skills.skillLevel.badge ####################################
    test_course_include_skillsskillLevelbadge("Test the include array objects for include=skill.skilllevel.badge","course:2022578","7133","7136","course:2022578_42400","course:2022578_42406","42400_1","42406_2")
    test_course_include_skillbadge("Test the skillbadge associated with the course","course:2022578","7133","7136")
    test_course_include_skilllevel("Test the skilllevel associated with the course in include array","course:2022578","42400_1","42406_2")
    test_course_include_courseskill("Test the course skill associated with the course","course:2022578","course:2022578_42406","course:2022578_42400")
    ######################### include=prerequisiteLOs.instances #################################
    test_course_include_prerequisiteinstance("Trst the include array objects include=prerequisitelo.instance","course:2022578","course:2021912_3701012","course:2021912")
    test_course_include_prerequisiteskills("Test the include array objects with include=prerequisiteLOs.skills","course:2022578","course:2021912_42400","course:2021912_42401","course:2021912")
    test_course_include_prerequisiteauthor("Test the include array objects with include=prerequisiteLOs.authors","course:2022578","6530751","course:2021912")
    ######################### include=skills.skillLevel.skill.levels #############################
    test_course_include_skillsskillLevelskilllevels("Test the include array objects with include=skills.skillLevel.skill.levels","course:2022578","course:2022578_42400","course:2022578_42406","42400","42406","42400_1","42406_2","42406_1","42406_3")
    test_course_include_skillobjects("Test the skills object in the include array","course:2022578","42400","42406")
    test_course_include_skilllevelobjects("Test the skill level objects in the include array","course:2022578","42400_1","42406_2","42406_1","42406_3")
    test_course_include_loskill("Test the course skill objects in the include array","course:2022578","course:2022578_42400","course:2022578_42406")
    ######################### include=supplementaryLOs.instances.loResources.resources ###################
    test_course_include_supplimentarylo("Test the objects in include array for include=supplementaryLOs.instances.loResources.resources","course:2022578","jobAid:9688","jobAid:9689","jobAid:9690","jobAid:9690_-1_-1_1","jobAid:9689_-1_-1_1","jobAid:9688_-1_-1_1","jobAid:9690_-1_-1_1_resource","jobAid:9689_-1_-1_1_resource","jobAid:9688_-1_-1_1_resource","jobAid:9690_-1","jobAid:9689_-1","jobAid:9688_-1")
    test_course_include_supplimentaryloobjects("Test the supplimentary objects in the include array","course:2022578","jobAid:9688","jobAid:9689","jobAid:9690")
    test_course_include_jobaidloresource("Test the jobaid learning object resource in include array","course:2022578","jobAid:9690_-1_-1_1","jobAid:9689_-1_-1_1","jobAid:9688_-1_-1_1")
    test_course_include_jobaidresource("Test the jobaid resource object in the include array","course:2022578","jobAid:9688_-1_-1_1_resource","jobAid:9689_-1_-1_1_resource","jobAid:9690_-1_-1_1_resource")
    test_course_include_jobaidinstance("Test the jobaid instance objects in the include array","course:2022578","jobAid:9688_-1","jobAid:9689_-1","jobAid:9690_-1")
    ################################ include=supplementaryResources,instances.loResources.resources ####################
    test_course_include_supplimentaryresource("Test the objects in include array with include=supplementaryResources,instances.loResources.resources","course:2022578","course:2022578_3701730","course:2022578_3701731","course:2022578_3701732","course:2022578_2022578_2_attachment","course:2022578_2022578_1_attachment","580662_1_en-US","course:2022578_3701731_2659937_0_resource","course:2022578_3701732_2659937_0_resource","580668_2_en-US","580667_1_en-US","course:2022578_3701732_2659940_0_resource","course:2022578_3701730_2659937_0_resource","course:2022578_3701730_2659940_0_resource","course:2022578_3701731_2659940_0_resource","course:2022578_3701730_2659936_0","course:2022578_3701731_2659936_0","course:2022578_3701732_2659936_0","course:2022578_3701730_2659937_0","course:2022578_3701731_2659937_0","course:2022578_3701732_2659937_0","course:2022578_3701730_2659938_0","course:2022578_3701731_2659938_0","course:2022578_3701732_2659938_0","course:2022578_3701730_2659939_0","course:2022578_3701731_2659939_0","course:2022578_3701732_2659939_0","course:2022578_3701730_2659940_0","course:2022578_3701731_2659940_0","course:2022578_3701732_2659940_0")
    test_course_include_supplimentaryresourceobject("Test the attachment contents in the include array","course:2022578","course:2022578_2022578_2_attachment","course:2022578_2022578_1_attachment")
    ################################ include=enrollment.loinstance ########################################################
    test_course_include_enrollmentinstance("Test the objects in the include array for the include=enrollment.loinstance","course:2022594","course:2022594_3701748_6530751","course:2022594_3701748")
    test_course_include_enrolledinstance("Test the loinstance enrolled to the learner ","course:2022594","course:2022594_3701748")
    test_course_include_enrolledobject("Test the enrollment object in the include array","course:2022594","course:2022594_3701748_6530751")
    ################################### include=enrollment.learnerBadge.badge  ##############################
    test_course_include_enrollmentlearnerbadge("Test the include array objects for include=enrollment.learnerBadge.badge","course:2022594","course:2022594_3701748_6530751","6530751_7133_COURSE_2022594","7133")
    test_course_include_enrolledobjectlearnerbadge("Test the enrollement object in include array","course:2022594","course:2022594_3701748_6530751")
    test_course_include_learnerbadge("Test the userbadge object in the include array","course:2022594","6530751_7133_COURSE_2022594")
    test_course_include_badgeenrollement("Test the badge object associated with the course instance in include array","course:2022594","7133")
    ################################## include=enrollment.learnerBadge.learner ###############################
    test_course_include_enrollmentlearnerbadgelearner("Test the include array objects for include=enrollment.learnerBadge.learner","course:2022594","course:2022594_3701748_6530751","6530751","6530751_7133_COURSE_2022594")
    test_course_include_learnerenrollment("Test the learner object in include array to whom course is enrolled","course:2022594","6530751")
    ################################# include=enrollment.learnerBadge.model ##########################
    test_course_include_enrollmentmodel("Test the include array objects for the include=enrollment.learnerBadge.model","course:2022594","course:2022594_3701748_6530751","6530751_7133_COURSE_2022594")
    ################################## include=enrollment.learnerBadge.model.instances #########################
    test_course_include_enrollmentmodelinstances("Test the include array objects for the include=enrollment.learnerBadge.model.instances","course:2022594","course:2022594_3701748","course:2022594_3701749","6530751_7133_COURSE_2022594","course:2022594_3701748_6530751")
    ################################## include=enrollment.loResourceGrades.loResource #######################
    test_course_include_enrollmenloresourcegrades("Test the include array objects for the include=enrollment.loResourceGrades.loResource","course:2022594","course:2022594_3701748_6530751","course:2022594_3701748_2659960_0","course:2022594_3701748_2659959_0","course:2022594_3701748_2659958_0","course:2022594_3701748_2659957_0","course:2022594_3701748_2659956_0","course:2022594_3701748_2659960_0_1a75406751ec40efa3500f37c7f93268_8751146055f64732ad15eaaaad645a03","course:2022594_3701748_2659959_0_1a75406751ec40efa3500f37c7f93268_dc21c90fcc8d410a8a38aaf18952faa8","course:2022594_3701748_2659958_0_1a75406751ec40efa3500f37c7f93268_48521ec115e7493087061210a877ec40","course:2022594_3701748_2659957_0_1a75406751ec40efa3500f37c7f93268_cb36457c5084457ca39e0c4658d9b8e6","course:2022594_3701748_2659956_0_1a75406751ec40efa3500f37c7f93268_1902caf4764245d6b489446f00148a47")
    Auto_close()
