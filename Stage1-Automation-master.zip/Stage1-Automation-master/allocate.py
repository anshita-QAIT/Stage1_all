from concurrent.futures import ProcessPoolExecutor

task_queue=[]

def fill_test_queue(tasks):
    task_queue+=tasks

def execute_task():
   with ProcessPoolExecutor() as p:
        task_result=[p.submit(job) for job in task_queue]
        done,not_done=concurrent.futures.wait(future,return_when=concurrent.futures.ALL_COMPLETED)
        for fut in done:
          print(fut.result())
   task_queue.clear()
