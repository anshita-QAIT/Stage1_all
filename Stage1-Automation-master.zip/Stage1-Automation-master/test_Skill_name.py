from utility import *
from time import time
import json

#taga@faga.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test_SKILLNAME_Course(testcase,SKILL_NAME,obj_len,*args):
    data = get_data()
    data.clear()
    data["filter.skillName"] = SKILL_NAME
    data["page[offset]"] =0
    data["page[limit]"]=10
    data["filter.loTypes"] ="course"
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       cid=[]
       for obj in res["data"]:
          cid.append(obj["id"])
       for i in args:
          if i not in cid:
            return False
       if len(cid)!=obj_len:
          return False
       return True
    except Exception as e:
        return False


@Report_generate
def test_SKILLNAME_TAG_Course(testcase,SKILL_NAME,TAG_NAME,obj_len,*args):
    data = get_data()
    data.clear()
    data["filter.skillName"]=SKILL_NAME
    data["page[offset]"] =0
    data["page[limit]"]=10
    data["filter.loTypes"] ="course"
    data["filter.tagName"] =TAG_NAME
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       cid=[]
       for obj in res["data"]:
          cid.append(obj["id"])
       for i in args:
          if i not in cid:
            return False
       if len(cid)!=obj_len:
          return False
       return True
    except Exception as e:
        return False



@Report_generate
def test_SKILLNAMES_TAG_Course(testcase,SKILL_NAME1,SKILL_NAME2,TAG_NAME,obj_len,*args):
    data = get_data()
    data.clear()
    data["filter.skillName"] =SKILL_NAME1+","+SKILL_NAME2
    data["page[offset]"] =0
    data["page[limit]"]=10
    data["filter.loTypes"] ="course"
    data["filter.tagName"] =TAG_NAME
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       cid=[]
       for obj in res["data"]:
          cid.append(obj["id"])
       for i in args:
          if i not in cid:
            return False
       if len(cid)!=obj_len:
          return False
       return True
    except Exception as e:
        return False


if __name__=="__main__":
   Auto_init("Test_LO_skill.csv")
   set_modulename(__file__)
   Env_init("7a5fca40-1013-4166-bb92-cee58a43a980","54cda52b-f078-42e3-8a75-ad3b605166f7","31cafab8def2491b6bd0395dd72974c8")
   test_SKILLNAME_Course("Test the course objects associated with SKILLA","SKILLA",7,"course:3038917","course:3038918","course:3038916","course:3038911","course:3038920","course:3038914","course:3038915")
   test_SKILLNAME_Course("Test the course objects associated with SKILLB","SKILLB",8,"course:3038925","course:3038923","course:3038924","course:3038917","course:3038918","course:3038916","course:3038922","course:3038921")
   test_SKILLNAME_TAG_Course("Test the course objects associated with SKILLA and tag5","SKILLA","tag5",3,"course:3038917","course:3038911","course:3038920")
   test_SKILLNAME_TAG_Course("Test the course objects associated with SKILLA and tag5","SKILLA","tag8",1,"course:3038920")
   test_SKILLNAME_TAG_Course("Test the course objects associated with SKILLA and tag6","SKILLA","tag6",4,"course:3038918","course:3038916","course:3038914","course:3038915")
   test_SKILLNAME_TAG_Course("Test the course objects associated with SKILLA and tag7","SKILLA","tag7",2,"course:3038916","course:3038915")
   test_SKILLNAME_TAG_Course("Test the course objects associated with SKILLB and tag5","SKILLB","tag5",4,"course:3038925","course:3038923","course:3038917","course:3038922")
   test_SKILLNAME_TAG_Course("Test the course objects associated with SKILLB and tag6","SKILLB","tag6",5,"course:3038925","course:3038924","course:3038918","course:3038916","course:3038921")
   test_SKILLNAME_TAG_Course("Test the course objects associated with SKILLB and tag8","SKILLB","tag8",2,"course:3038924","course:3038922")
   test_SKILLNAME_TAG_Course("Test the course objects associated with SKILLB and test7","SKILLB","tag7",2,"course:3038923","course:3038916")
   test_SKILLNAMES_TAG_Course("Test the course objects associated with SKILLA ,SKILLB and tag6","SKILLA","SKILLB","tag6",7,"course:3038925","course:3038924","course:3038918","course:3038916","course:3038914","course:3038915","course:3038921")
   Auto_close()
