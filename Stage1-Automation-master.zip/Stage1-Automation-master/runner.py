import glob
import os
import datetime
import shutil

SRC='./logger/Run.log'
TAR='Run.log'

python_files=glob.glob('*.py')

def remove_files(*args):
  global python_files
  for i in args:
    python_files.remove(i)

remove_files('runner.py','utility.py','report.py','allocate.py','startup.py','master_runner.py')

for file in python_files:
       os.system('py'+' '+file)

os.system('py report.py')

try:
   shutil.copyfile(SRC,TAR)
   os.remove(SRC) 
except Exception as e:
    print("Missing run log")






