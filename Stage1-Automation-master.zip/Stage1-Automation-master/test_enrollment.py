from utility import *
from time import time
import json


#bapan1690814+9093@gmail.com


######################################################################### UTILITY METHODS ########################################

# POST request function for testing basic functionality of POST method.
@post_request
def post_enrollment(*args):
    return args[3]


# GET request function to retrieve the user by id.
@get_request
def get_enrollment_user_body_by_id(*args):
    return args[1]


# GET request function to retrieve the user by id.
@get_request
def get_enrollment_user_status_by_id(*args):
    return args[2]


# DELETE user enrollment.
@delete_request_parameter
def delete_enrollment_by_id(*args):
    return args[1]


# POST request function for testing basic functionality of POST method.
@post_request
def post_enrollment_get_body(*args):
    return args[2]


################################################################# Validation Methods ##############################################

@Report_generate
def test_enrollment_of_course(Testcase, courseinstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = courseinstance.split('_')[0]
        data["loInstanceId"] = courseinstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment(str1, data)
        print(res)
        if res == 200:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_enrollment_of_certificate(Testcase, certificateinstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = certificateinstance.split('_')[0]
        data["loInstanceId"] = certificateinstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment(str1, data)
        print(res)
        if res == 200:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_enrollment_of_LP(Testcase, learningprograminstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = learningprograminstance.split('_')[0]
        data["loInstanceId"] = learningprograminstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment(str1, data)
        print(res)
        if res == 200:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_enrollment_body_course(Testcase, courseinstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = courseinstance.split('_')[0]
        data["loInstanceId"] = courseinstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment_get_body(str1, data)
        print(res)
        str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
        res_get = get_enrollment_user_body_by_id(str1)
        print(res_get)
        if res_get["data"]["id"] == res["data"]["id"]:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_enrollment_body_LP(Testcase, learningprograminstance, userid):
   try:
       global data
       data = get_data()
       data.clear()
       data["loId"] = learningprograminstance.split('_')[0]
       data["loInstanceId"] = learningprograminstance
       str1 = "users/" + str(userid) + "/enrollments"
       res = post_enrollment_get_body(str1, data)
       str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
       res_get = get_enrollment_user_body_by_id(str1)
       if res_get["data"]["id"] == res["data"]["id"]:
           return True
       else:
           return False
   except Exception as e:
       return False


@Report_generate
def test_enrollment_body_certificate(Testcase, certificateinstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = certificateinstance.split('_')[0]
        data["loInstanceId"] = certificateinstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment_get_body(str1, data)
        str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
        res_get = get_enrollment_user_body_by_id(str1)
        if res_get["data"]["id"] == res["data"]["id"]:
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_unenrollment_of_course(Testcase, courseinstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = courseinstance.split('_')[0]
        data["loInstanceId"] = courseinstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment_get_body(str1, data)
        str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
        res_delete = delete_enrollment_by_id(str1)
        print(res_delete)
        if res_delete == 200:
            res_get = get_enrollment_user_status_by_id(str1)
            if res_get == 400:
                return True
            else:
                return False
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_unenrollment_of_LP(Testcase, learningprograminstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = learningprograminstance.split('_')[0]
        data["loInstanceId"] = learningprograminstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment_get_body(str1, data)
        str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
        res_delete = delete_enrollment_by_id(str1)
        print(res_delete)
        if res_delete == 200:
            res_get = get_enrollment_user_status_by_id(str1)
            if res_get == 400:
                return True
            else:
                return False
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_unenrollment_of_certificate(Testcase, certificateinstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = certificateinstance.split('_')[0]
        data["loInstanceId"] = certificateinstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment_get_body(str1, data)
        print(res)
        str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
        res_delete = delete_enrollment_by_id(str1)
        print(res_delete)
        if res_delete == 200:
            res_get = get_enrollment_user_status_by_id(str1)
            if res_get == 400:
                return True
            else:
                return False
        else:
            return False
    except Exception as e:
         return False

@Report_generate
def test_started_status_of_certificate(Testcase, certificateinstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = certificateinstance.split('_')[0]
        data["loInstanceId"] = certificateinstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment_get_body(str1, data)
        str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
        res_get = get_enrollment_user_body_by_id(str1)
        if res_get["data"]["attributes"]["state"] == "STARTED":
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_completed_status_of_certificate(Testcase, certificateinstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = certificateinstance.split('_')[0]
        data["loInstanceId"] = certificateinstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment_get_body(str1, data)
        str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
        res_get = get_enrollment_user_body_by_id(str1)
        if res_get["data"]["attributes"]["state"] == "COMPLETED":
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_started_status_of_course(Testcase, courseinstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = courseinstance.split('_')[0]
        data["loInstanceId"] = courseinstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment_get_body(str1, data)
        str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
        res_get = get_enrollment_user_body_by_id(str1)
        if res_get["data"]["attributes"]["state"] == "STARTED":
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_completed_status_of_course(Testcase, courseinstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = courseinstance.split('_')[0]
        data["loInstanceId"] = courseinstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment_get_body(str1, data)
        str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
        res_get = get_enrollment_user_body_by_id(str1)
        if res_get["data"]["attributes"]["state"] == "COMPLETED":
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_started_status_of_LP(Testcase, courseinstance, userid):
    try:
        global data
        data = get_data()
        data.clear()
        data["loId"] = courseinstance.split('_')[0]
        data["loInstanceId"] = courseinstance
        str1 = "users/" + str(userid) + "/enrollments"
        res = post_enrollment_get_body(str1, data)
        str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
        res_get = get_enrollment_user_body_by_id(str1)
        if res_get["data"]["attributes"]["state"] == "STARTED":
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_completed_status_of_LP(Testcase, courseinstance, userid):
   try:
       global data
       data = get_data()
       data.clear()
       data["loId"] = courseinstance.split('_')[0]
       data["loInstanceId"] = courseinstance
       str1 = "users/" + str(userid) + "/enrollments"
       res = post_enrollment_get_body(str1, data)
       str1 = str1 + "/" + res["data"]["id"].split(":")[0] + "%3A" + res["data"]["id"].split(":")[1]
       res_get = get_enrollment_user_body_by_id(str1)
       if res_get["data"]["attributes"]["state"] == "COMPLETED":
           return True
       else:
           return False
   except Exception as e:
       return False


###################################################### TEST SCRIPTS ############################################################


if __name__ == "__main__":
    Auto_init("Enrollment.csv")
    set_modulename(__file__)
    Env_init("190d807b-04be-491f-85b9-24205441a0c0", "484e91fe-6b1d-4906-8b92-f87f89f495d1",
             "aa24e0f1697ef6ec8e4d0d5c8d0c8dc8")
    print(cred)
    test_enrollment_of_course("Test the enrollment request of course instance", "course:1988368_3667509", 5640670)
    test_enrollment_of_certificate("Test the enrollment request of certificate instance", "certification:61636_95371",
                                   5640670)
    test_enrollment_of_LP("Test the enrollment request of learning program", "learningProgram:36897_44330", 5640670)
    test_enrollment_body_course("Test the enrollment request course and verify using GET by id",
                                "course:1988368_3667509", 5640670)
    test_enrollment_body_LP("Test the enrollment request LP and verify using GET by id", "learningProgram:36897_44330",
                            5640670)
    test_enrollment_body_certificate("Test the enrollment request certificate and verify using GET by id",
                                     "certification:61636_95371", 5640670)
    test_unenrollment_of_course("Test the unenrollment request for the course", "course:1988368_3667509", 5640670)
    test_unenrollment_of_LP("Test the unenrollment request for learning program", "learningProgram:36897_44330",
                            5640670)
    test_unenrollment_of_certificate("Test the unenrollment request for certificate", "certification:61636_95371",
                                     5640670)
    test_started_status_of_certificate("Test the started status of the certificate enrollment",
                                       "certification:61612_95347_5640670", 5640670)
    test_completed_status_of_certificate("Test the completion status of certificate enrollment",
                                         "certification:61617_95352", 5640670)
    test_started_status_of_course("Test the started status of course enrollment", "course:1988545_3667686", 5640670)
    test_completed_status_of_course("Test the completed status of course enrollment", "course:1988550_3667692", 5640670)
    test_started_status_of_LP("Test the started status of LP enrollment", "learningProgram:36933_44331", 5640670)
    test_completed_status_of_LP("Test the completion status of LP enrollment", "learningProgram:36936_44332", 5640670)
    Auto_close()